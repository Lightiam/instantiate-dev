import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface RealDeploymentResult {
  success: boolean;
  deploymentId: string;
  deployment?: any;
  resourceGroup?: string;
  containerName?: string;
  error?: string;
  message: string;
}

export function RealDeploymentTest() {
  const [activeDeployment, setActiveDeployment] = useState<string | null>(null);
  const [deploymentResults, setDeploymentResults] = useState<RealDeploymentResult[]>([]);
  const { toast } = useToast();

  // Azure deployment form state
  const [azureForm, setAzureForm] = useState({
    name: 'instanti8-test-app',
    image: 'mcr.microsoft.com/azuredocs/aci-helloworld',
    resourceGroup: 'instanti8-real-test',
    location: 'eastus',
    cpu: 0.5,
    memory: 1,
    ports: '80',
    envVars: 'TEST_TYPE=real_deployment\nDEPLOYMENT_SOURCE=instanti8'
  });

  // Replit deployment form state
  const [replitForm, setReplitForm] = useState({
    name: 'instanti8-replit-test',
    template: 'node-express',
    description: 'Real Replit deployment test from Instanti8 platform',
    envVars: 'NODE_ENV=production\nAPP_NAME=instanti8-test'
  });

  // Azure deployment mutation
  const azureDeployMutation = useMutation({
    mutationFn: (formData: typeof azureForm) => {
      const envVarsObj = formData.envVars
        .split('\n')
        .filter(line => line.includes('='))
        .reduce((acc, line) => {
          const [key, ...valueParts] = line.split('=');
          acc[key.trim()] = valueParts.join('=').trim();
          return acc;
        }, {} as Record<string, string>);

      return apiRequest('/api/real-deploy/azure', {
        method: 'POST',
        body: {
          name: formData.name,
          image: formData.image,
          resourceGroup: formData.resourceGroup,
          location: formData.location,
          cpu: Number(formData.cpu),
          memory: Number(formData.memory),
          ports: formData.ports.split(',').map(p => Number(p.trim())),
          environmentVariables: envVarsObj
        }
      });
    },
    onSuccess: (data: RealDeploymentResult) => {
      setDeploymentResults(prev => [...prev, data]);
      if (data.success) {
        setActiveDeployment(data.deploymentId);
        toast({
          title: "Azure Deployment Started",
          description: `Real deployment ${data.deploymentId} initiated successfully`
        });
      } else {
        toast({
          title: "Azure Deployment Failed",
          description: data.error || "Failed to start real Azure deployment",
          variant: "destructive"
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Azure Deployment Error",
        description: error.message || "Failed to connect to Azure services",
        variant: "destructive"
      });
    }
  });

  // Replit deployment mutation
  const replitDeployMutation = useMutation({
    mutationFn: (formData: typeof replitForm) => {
      const envVarsObj = formData.envVars
        .split('\n')
        .filter(line => line.includes('='))
        .reduce((acc, line) => {
          const [key, ...valueParts] = line.split('=');
          acc[key.trim()] = valueParts.join('=').trim();
          return acc;
        }, {} as Record<string, string>);

      return apiRequest('/api/real-deploy/replit', {
        method: 'POST',
        body: {
          name: formData.name,
          template: formData.template,
          description: formData.description,
          environmentVariables: envVarsObj
        }
      });
    },
    onSuccess: (data: RealDeploymentResult) => {
      setDeploymentResults(prev => [...prev, data]);
      if (data.success) {
        setActiveDeployment(data.deploymentId);
        toast({
          title: "Replit Deployment Started",
          description: `Real deployment ${data.deploymentId} initiated successfully`
        });
      } else {
        toast({
          title: "Replit Deployment Failed",
          description: data.error || "Failed to start real Replit deployment",
          variant: "destructive"
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Replit Deployment Error",
        description: error.message || "Failed to connect to Replit services",
        variant: "destructive"
      });
    }
  });

  const handleAzureSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    azureDeployMutation.mutate(azureForm);
  };

  const handleReplitSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    replitDeployMutation.mutate(replitForm);
  };

  const getStatusColor = (success: boolean) => {
    return success ? 'bg-green-500' : 'bg-red-500';
  };

  const clearResults = () => {
    setDeploymentResults([]);
    setActiveDeployment(null);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Azure Real Deployment */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>☁️</span>
              <span>Real Azure Deployment</span>
            </CardTitle>
            <CardDescription>
              Deploy actual container instances to Azure with emoji status tracking
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAzureSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="azure-name">Container Name</Label>
                  <Input
                    id="azure-name"
                    value={azureForm.name}
                    onChange={(e) => setAzureForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="my-app"
                  />
                </div>
                <div>
                  <Label htmlFor="azure-rg">Resource Group</Label>
                  <Input
                    id="azure-rg"
                    value={azureForm.resourceGroup}
                    onChange={(e) => setAzureForm(prev => ({ ...prev, resourceGroup: e.target.value }))}
                    placeholder="my-resource-group"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="azure-image">Container Image</Label>
                <Input
                  id="azure-image"
                  value={azureForm.image}
                  onChange={(e) => setAzureForm(prev => ({ ...prev, image: e.target.value }))}
                  placeholder="mcr.microsoft.com/azuredocs/aci-helloworld"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="azure-location">Location</Label>
                  <Select value={azureForm.location} onValueChange={(value) => setAzureForm(prev => ({ ...prev, location: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="eastus">East US</SelectItem>
                      <SelectItem value="westus2">West US 2</SelectItem>
                      <SelectItem value="westeurope">West Europe</SelectItem>
                      <SelectItem value="southeastasia">Southeast Asia</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="azure-cpu">CPU Cores</Label>
                  <Input
                    id="azure-cpu"
                    type="number"
                    step="0.1"
                    min="0.1"
                    max="4"
                    value={azureForm.cpu}
                    onChange={(e) => setAzureForm(prev => ({ ...prev, cpu: Number(e.target.value) }))}
                  />
                </div>
                <div>
                  <Label htmlFor="azure-memory">Memory (GB)</Label>
                  <Input
                    id="azure-memory"
                    type="number"
                    step="0.1"
                    min="0.1"
                    max="16"
                    value={azureForm.memory}
                    onChange={(e) => setAzureForm(prev => ({ ...prev, memory: Number(e.target.value) }))}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="azure-ports">Ports (comma-separated)</Label>
                <Input
                  id="azure-ports"
                  value={azureForm.ports}
                  onChange={(e) => setAzureForm(prev => ({ ...prev, ports: e.target.value }))}
                  placeholder="80,443"
                />
              </div>

              <div>
                <Label htmlFor="azure-env">Environment Variables</Label>
                <Textarea
                  id="azure-env"
                  value={azureForm.envVars}
                  onChange={(e) => setAzureForm(prev => ({ ...prev, envVars: e.target.value }))}
                  placeholder="KEY1=value1&#10;KEY2=value2"
                  rows={3}
                />
              </div>

              <Button
                type="submit"
                disabled={azureDeployMutation.isPending}
                className="w-full"
              >
                {azureDeployMutation.isPending ? 'Deploying to Azure...' : 'Deploy to Azure'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Replit Real Deployment */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>🚀</span>
              <span>Real Replit Deployment</span>
            </CardTitle>
            <CardDescription>
              Deploy applications to Replit infrastructure with status tracking
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleReplitSubmit} className="space-y-4">
              <div>
                <Label htmlFor="replit-name">Project Name</Label>
                <Input
                  id="replit-name"
                  value={replitForm.name}
                  onChange={(e) => setReplitForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="my-replit-app"
                />
              </div>

              <div>
                <Label htmlFor="replit-template">Template</Label>
                <Select value={replitForm.template} onValueChange={(value) => setReplitForm(prev => ({ ...prev, template: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="node-express">Node.js Express</SelectItem>
                    <SelectItem value="python-flask">Python Flask</SelectItem>
                    <SelectItem value="react">React</SelectItem>
                    <SelectItem value="nextjs">Next.js</SelectItem>
                    <SelectItem value="html-css-js">HTML/CSS/JS</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="replit-desc">Description</Label>
                <Input
                  id="replit-desc"
                  value={replitForm.description}
                  onChange={(e) => setReplitForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Project description"
                />
              </div>

              <div>
                <Label htmlFor="replit-env">Environment Variables</Label>
                <Textarea
                  id="replit-env"
                  value={replitForm.envVars}
                  onChange={(e) => setReplitForm(prev => ({ ...prev, envVars: e.target.value }))}
                  placeholder="NODE_ENV=production&#10;APP_NAME=my-app"
                  rows={3}
                />
              </div>

              <Button
                type="submit"
                disabled={replitDeployMutation.isPending}
                className="w-full"
              >
                {replitDeployMutation.isPending ? 'Deploying to Replit...' : 'Deploy to Replit'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Active Deployment Status */}
      {activeDeployment && (
        <Card>
          <CardHeader>
            <CardTitle>Active Real Deployment</CardTitle>
            <CardDescription>
              Real-time status for deployment: {activeDeployment}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Status</span>
                <Badge className="bg-blue-500">🚀 Running</Badge>
              </div>
              <Progress value={85} className="w-full" />
              <p className="text-sm text-muted-foreground">
                📦 Deploying container to cloud infrastructure...
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Deployment Results */}
      {deploymentResults.length > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Real Deployment Results</CardTitle>
              <CardDescription>
                Results from actual deployments to cloud providers
              </CardDescription>
            </div>
            <Button onClick={clearResults} variant="outline" size="sm">
              Clear Results
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {deploymentResults.map((result, index) => (
                <div key={index} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{result.deploymentId}</p>
                      <p className="text-sm text-muted-foreground">{result.message}</p>
                    </div>
                    <Badge className={getStatusColor(result.success)}>
                      {result.success ? '✅ Success' : '❌ Failed'}
                    </Badge>
                  </div>
                  
                  {result.deployment && (
                    <div className="bg-muted p-3 rounded text-sm">
                      <p><strong>Resource Group:</strong> {result.resourceGroup}</p>
                      <p><strong>Container:</strong> {result.containerName}</p>
                      {result.deployment.url && (
                        <p><strong>URL:</strong> <a href={result.deployment.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{result.deployment.url}</a></p>
                      )}
                    </div>
                  )}
                  
                  {result.error && (
                    <div className="bg-red-50 border border-red-200 rounded p-3">
                      <p className="text-sm text-red-800">
                        <strong>Error:</strong> {result.error}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}