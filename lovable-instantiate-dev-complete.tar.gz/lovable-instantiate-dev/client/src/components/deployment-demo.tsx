import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';

interface DeploymentStage {
  stage: string;
  message: string;
  emoji: string;
  timestamp: string;
  duration?: number;
}

interface DemoProps {
  onComplete?: (result: any) => void;
}

export function DeploymentDemo({ onComplete }: DemoProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [currentStage, setCurrentStage] = useState(0);
  const [progress, setProgress] = useState(0);
  const [stages, setStages] = useState<DeploymentStage[]>([]);
  const [deploymentId] = useState(`demo-${Date.now()}`);

  const deploymentStages = [
    { stage: 'initializing', message: 'Starting deployment process', emoji: '🚀', delay: 1000 },
    { stage: 'validating', message: 'Validating configuration', emoji: '🔍', delay: 1500 },
    { stage: 'authenticating', message: 'Authenticating with cloud provider', emoji: '🔐', delay: 1000 },
    { stage: 'creating-resource-group', message: 'Creating resource group', emoji: '📁', delay: 2000 },
    { stage: 'building-image', message: 'Building container image', emoji: '🔨', delay: 2500 },
    { stage: 'deploying-container', message: 'Deploying container instance', emoji: '📦', delay: 2000 },
    { stage: 'starting-services', message: 'Starting application services', emoji: '▶️', delay: 1500 },
    { stage: 'health-checking', message: 'Running health checks', emoji: '🩺', delay: 1000 },
    { stage: 'verifying-deployment', message: 'Verifying deployment status', emoji: '✅', delay: 800 },
    { stage: 'deployment-complete', message: 'Deployment completed successfully', emoji: '🎉', delay: 500 }
  ];

  const runDeploymentDemo = async () => {
    setIsRunning(true);
    setCurrentStage(0);
    setProgress(0);
    setStages([]);

    for (let i = 0; i < deploymentStages.length; i++) {
      const stage = deploymentStages[i];
      
      await new Promise(resolve => setTimeout(resolve, stage.delay));
      
      const newStage: DeploymentStage = {
        ...stage,
        timestamp: new Date().toISOString(),
        duration: stage.delay
      };

      setStages(prev => [...prev, newStage]);
      setCurrentStage(i);
      setProgress(Math.round(((i + 1) / deploymentStages.length) * 100));

      // Add warning during health check
      if (stage.stage === 'health-checking') {
        await new Promise(resolve => setTimeout(resolve, 500));
        const warningStage: DeploymentStage = {
          stage: 'warning',
          message: 'Service startup took longer than expected',
          emoji: '⚠️',
          timestamp: new Date().toISOString(),
          duration: 500
        };
        setStages(prev => [...prev, warningStage]);
      }
    }

    setIsRunning(false);
    
    if (onComplete) {
      onComplete({
        deploymentId,
        status: 'success',
        stages: stages.length,
        totalTime: deploymentStages.reduce((sum, s) => sum + s.delay, 0)
      });
    }
  };

  const runErrorDemo = async () => {
    setIsRunning(true);
    setCurrentStage(0);
    setProgress(0);
    setStages([]);

    const errorStages = [
      { stage: 'initializing', message: 'Starting deployment process', emoji: '🚀', delay: 800 },
      { stage: 'validating', message: 'Validating configuration', emoji: '🔍', delay: 1000 },
      { stage: 'authenticating', message: 'Authenticating with cloud provider', emoji: '🔐', delay: 1200 },
      { stage: 'warning', message: 'Authentication token expired', emoji: '⚠️', delay: 800 },
      { stage: 'error', message: 'Authentication failed - invalid credentials', emoji: '❌', delay: 500 }
    ];

    for (let i = 0; i < errorStages.length; i++) {
      const stage = errorStages[i];
      
      await new Promise(resolve => setTimeout(resolve, stage.delay));
      
      const newStage: DeploymentStage = {
        ...stage,
        timestamp: new Date().toISOString(),
        duration: stage.delay
      };

      setStages(prev => [...prev, newStage]);
      setCurrentStage(i);
      setProgress(Math.round(((i + 1) / errorStages.length) * 60)); // Cap at 60% for error
    }

    setIsRunning(false);
    
    if (onComplete) {
      onComplete({
        deploymentId: `error-${Date.now()}`,
        status: 'failed',
        reason: 'authentication_error'
      });
    }
  };

  const getCurrentStageInfo = () => {
    if (stages.length === 0) return null;
    const latest = stages[stages.length - 1];
    return latest;
  };

  const currentStageInfo = getCurrentStageInfo();

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <span>Emoji-Based Deployment Demo</span>
            {isRunning && <span className="animate-pulse">🔄</span>}
          </CardTitle>
          <CardDescription>
            Test the visual status tracking system with realistic deployment scenarios
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-2">
            <Button
              onClick={runDeploymentDemo}
              disabled={isRunning}
              className="flex-1"
            >
              {isRunning ? 'Running Demo...' : '🚀 Test Success Scenario'}
            </Button>
            <Button
              onClick={runErrorDemo}
              disabled={isRunning}
              variant="outline"
              className="flex-1"
            >
              {isRunning ? 'Running Error Demo...' : '❌ Test Error Scenario'}
            </Button>
          </div>

          {isRunning && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Deployment Progress</span>
                <Badge variant="secondary">{progress}%</Badge>
              </div>
              <Progress value={progress} className="w-full" />
              
              {currentStageInfo && (
                <div className="flex items-center space-x-2 p-3 bg-muted rounded-lg">
                  <span className="text-xl">{currentStageInfo.emoji}</span>
                  <div>
                    <p className="font-medium">{currentStageInfo.message}</p>
                    <p className="text-sm text-muted-foreground">
                      Stage: {currentStageInfo.stage}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {stages.length > 0 && !isRunning && (
            <div className="space-y-3">
              <Separator />
              <h4 className="font-medium">Deployment Timeline</h4>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {stages.map((stage, index) => (
                  <div key={index} className="flex items-center space-x-2 text-sm">
                    <span>{stage.emoji}</span>
                    <span className="flex-1">{stage.message}</span>
                    <span className="text-muted-foreground">
                      {stage.duration}ms
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}