import { AuthForm } from "@/components/ui/auth-form";
import { useLocation } from "wouter";

export default function Auth() {
  const [, setLocation] = useLocation();

  const handleAuthSuccess = (user: any) => {
    console.log("Authentication successful:", user);
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="text-xl font-bold text-primary font-mono">&lt;/&gt;</div>
            <span className="text-xl font-bold">Instanti8.dev</span>
          </div>
          <p className="text-slate-400">
            Infrastructure as Code deployment platform
          </p>
        </div>
        
        <AuthForm onSuccess={handleAuthSuccess} />
        
        <div className="text-center mt-6">
          <button 
            onClick={() => setLocation("/")}
            className="text-slate-400 hover:text-white transition-colors text-sm"
          >
            ← Back to home
          </button>
        </div>
      </div>
    </div>
  );
}