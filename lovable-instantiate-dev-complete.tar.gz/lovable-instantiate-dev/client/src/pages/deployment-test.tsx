import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface DeploymentStage {
  stage: string;
  message: string;
  emoji: string;
  timestamp: string;
  duration?: number;
}

interface DeploymentProgress {
  deploymentId: string;
  provider: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  currentStage: string;
  emoji: string;
  message: string;
  stages: DeploymentStage[];
  startTime: string;
  endTime?: string;
  duration?: string;
  error?: string;
}

export default function DeploymentTestPage() {
  const [activeDeployment, setActiveDeployment] = useState<string | null>(null);
  const [deploymentLogs, setDeploymentLogs] = useState<DeploymentProgress[]>([]);
  const { toast } = useToast();

  // Test emoji deployment demo
  const emojiDemoMutation = useMutation({
    mutationFn: () => apiRequest('/api/demo/deployment', { method: 'POST' }),
    onSuccess: (data) => {
      toast({
        title: "Demo Completed",
        description: "Emoji deployment demonstration finished successfully"
      });
      
      if (data && data.demo) {
        const mockProgress: DeploymentProgress = {
          deploymentId: data.demo.deploymentId,
          provider: 'demo',
          status: 'completed',
          progress: 100,
          currentStage: 'deployment-complete',
          emoji: '🎉',
          message: 'Demo deployment completed',
          stages: [
            { stage: 'initializing', message: 'Starting deployment', emoji: '🚀', timestamp: new Date().toISOString() },
            { stage: 'validating', message: 'Validating configuration', emoji: '🔍', timestamp: new Date().toISOString() },
            { stage: 'building', message: 'Building application', emoji: '🔨', timestamp: new Date().toISOString() },
            { stage: 'deploying', message: 'Deploying to cloud', emoji: '📦', timestamp: new Date().toISOString() },
            { stage: 'complete', message: 'Deployment successful', emoji: '✅', timestamp: new Date().toISOString() }
          ],
          startTime: new Date().toISOString(),
          endTime: new Date().toISOString(),
          duration: '12.5s'
        };
        
        setDeploymentLogs(prev => [...prev, mockProgress]);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Demo Failed",
        description: error.message || "Failed to run deployment demo",
        variant: "destructive"
      });
    }
  });

  // Test error handling demo
  const errorDemoMutation = useMutation({
    mutationFn: () => apiRequest('/api/demo/error-handling', { method: 'POST' }),
    onSuccess: (data) => {
      toast({
        title: "Error Demo Completed",
        description: "Error handling demonstration finished"
      });
      
      if (data && data.demo) {
        const mockErrorProgress: DeploymentProgress = {
          deploymentId: data.demo.deploymentId,
          provider: 'demo',
          status: 'failed',
          progress: 60,
          currentStage: 'error',
          emoji: '❌',
          message: 'Authentication failed',
          stages: [
            { stage: 'initializing', message: 'Starting deployment', emoji: '🚀', timestamp: new Date().toISOString() },
            { stage: 'validating', message: 'Validating configuration', emoji: '🔍', timestamp: new Date().toISOString() },
            { stage: 'authenticating', message: 'Authenticating with cloud', emoji: '🔐', timestamp: new Date().toISOString() },
            { stage: 'warning', message: 'Token expired', emoji: '⚠️', timestamp: new Date().toISOString() },
            { stage: 'error', message: 'Authentication failed', emoji: '❌', timestamp: new Date().toISOString() }
          ],
          startTime: new Date().toISOString(),
          endTime: new Date().toISOString(),
          duration: '4.2s',
          error: 'Invalid credentials provided'
        };
        
        setDeploymentLogs(prev => [...prev, mockErrorProgress]);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error Demo Failed",
        description: error.message || "Failed to run error demo",
        variant: "destructive"
      });
    }
  });

  // Test real Azure deployment
  const azureDeployMutation = useMutation({
    mutationFn: (deploymentSpec: any) => apiRequest('/api/azure/deploy', { 
      method: 'POST',
      body: deploymentSpec
    }),
    onSuccess: (data) => {
      if (data && data.success) {
        toast({
          title: "Azure Deployment Started",
          description: `Deployment ${data.deploymentId} initiated successfully`
        });
        setActiveDeployment(data.deploymentId);
      } else {
        toast({
          title: "Azure Deployment Failed",
          description: (data && data.message) || "Failed to start Azure deployment",
          variant: "destructive"
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Deployment Error",
        description: error.message || "Failed to deploy to Azure",
        variant: "destructive"
      });
    }
  });

  const handleTestAzureDeployment = () => {
    azureDeployMutation.mutate({
      name: 'emoji-test-app',
      image: 'mcr.microsoft.com/azuredocs/aci-helloworld',
      resourceGroup: 'instanti8-emoji-test',
      location: 'eastus',
      cpu: 0.5,
      memory: 1,
      ports: [80],
      environmentVariables: {
        TEST_MODE: 'true',
        FEATURE: 'emoji-status-tracking'
      }
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'failed': return 'bg-red-500';
      case 'running': return 'bg-blue-500';
      case 'pending': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const clearLogs = () => {
    setDeploymentLogs([]);
    setActiveDeployment(null);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Deployment Assistant Test</h1>
        <p className="text-muted-foreground">
          Test the emoji-based deployment status tracking system
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Test Controls */}
        <Card>
          <CardHeader>
            <CardTitle>Test Controls</CardTitle>
            <CardDescription>
              Run different deployment scenarios to test emoji-based status updates
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={() => emojiDemoMutation.mutate()}
              disabled={emojiDemoMutation.isPending}
              className="w-full"
            >
              {emojiDemoMutation.isPending ? '🚀 Running Demo...' : '🚀 Test Success Scenario'}
            </Button>

            <Button
              onClick={() => errorDemoMutation.mutate()}
              disabled={errorDemoMutation.isPending}
              variant="outline"
              className="w-full"
            >
              {errorDemoMutation.isPending ? '⚠️ Running Error Demo...' : '❌ Test Error Scenario'}
            </Button>

            <Separator />

            <Button
              onClick={handleTestAzureDeployment}
              disabled={azureDeployMutation.isPending}
              variant="secondary"
              className="w-full"
            >
              {azureDeployMutation.isPending ? '🔐 Connecting to Azure...' : '☁️ Test Azure Deployment'}
            </Button>

            <Button
              onClick={clearLogs}
              variant="destructive"
              size="sm"
              className="w-full"
            >
              Clear Test Logs
            </Button>
          </CardContent>
        </Card>

        {/* Active Deployment Status */}
        {activeDeployment && (
          <Card>
            <CardHeader>
              <CardTitle>Active Deployment</CardTitle>
              <CardDescription>
                Real-time status for deployment: {activeDeployment}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Status</span>
                  <Badge className="bg-blue-500">🚀 Running</Badge>
                </div>
                <Progress value={75} className="w-full" />
                <p className="text-sm text-muted-foreground">
                  🔨 Building container image...
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Feature Overview */}
        <Card className={activeDeployment ? "lg:col-span-1" : "lg:col-span-2"}>
          <CardHeader>
            <CardTitle>Emoji Status System Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div className="space-y-2">
                <div className="text-2xl">🚀</div>
                <p className="text-sm font-medium">Initialization</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl">🔍</div>
                <p className="text-sm font-medium">Validation</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl">🔨</div>
                <p className="text-sm font-medium">Building</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl">📦</div>
                <p className="text-sm font-medium">Deployment</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl">✅</div>
                <p className="text-sm font-medium">Success</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl">❌</div>
                <p className="text-sm font-medium">Error</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl">⚠️</div>
                <p className="text-sm font-medium">Warning</p>
              </div>
              <div className="space-y-2">
                <div className="text-2xl">🎉</div>
                <p className="text-sm font-medium">Complete</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Deployment Logs */}
      {deploymentLogs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Deployment History</CardTitle>
            <CardDescription>
              Recent deployment tests with emoji-based status tracking
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {deploymentLogs.map((deployment, index) => (
                <div key={index} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{deployment.emoji}</span>
                      <div>
                        <p className="font-medium">{deployment.deploymentId}</p>
                        <p className="text-sm text-muted-foreground">
                          Provider: {deployment.provider} • Duration: {deployment.duration}
                        </p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(deployment.status)}>
                      {deployment.status}
                    </Badge>
                  </div>
                  
                  <Progress value={deployment.progress} className="w-full" />
                  
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Deployment Stages:</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                      {deployment.stages.map((stage, stageIndex) => (
                        <div key={stageIndex} className="flex items-center space-x-2 text-sm">
                          <span>{stage.emoji}</span>
                          <span>{stage.message}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {deployment.error && (
                    <div className="bg-red-50 border border-red-200 rounded p-3">
                      <p className="text-sm text-red-800">
                        <strong>Error:</strong> {deployment.error}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}