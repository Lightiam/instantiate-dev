import { useState } from 'react';
import { DeploymentDemo } from '@/components/deployment-demo';
import { RealDeploymentTest } from '@/components/real-deployment-test';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface TestResult {
  deploymentId: string;
  status: 'success' | 'failed';
  stages?: number;
  totalTime?: number;
  reason?: string;
}

export default function TestSimplePage() {
  const [testResults, setTestResults] = useState<TestResult[]>([]);

  const handleDemoComplete = (result: TestResult) => {
    setTestResults(prev => [...prev, result]);
  };

  const clearResults = () => {
    setTestResults([]);
  };

  const getStatusColor = (status: string) => {
    return status === 'success' ? 'bg-green-500' : 'bg-red-500';
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Deployment Testing Platform</h1>
        <p className="text-muted-foreground">
          Test emoji-based deployment tracking with demonstrations and real deployments
        </p>
      </div>

      <Tabs defaultValue="demo" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="demo">Demo Deployments</TabsTrigger>
          <TabsTrigger value="real">Real Deployments</TabsTrigger>
        </TabsList>

        <TabsContent value="demo" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <DeploymentDemo onComplete={handleDemoComplete} />
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Emoji Status Features</CardTitle>
                <CardDescription>
                  Visual indicators used throughout the deployment process
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="space-y-2 p-3 border rounded">
                    <div className="text-2xl">🚀</div>
                    <p className="text-sm font-medium">Initialization</p>
                    <p className="text-xs text-muted-foreground">Starting deployment</p>
                  </div>
                  <div className="space-y-2 p-3 border rounded">
                    <div className="text-2xl">🔍</div>
                    <p className="text-sm font-medium">Validation</p>
                    <p className="text-xs text-muted-foreground">Checking configuration</p>
                  </div>
                  <div className="space-y-2 p-3 border rounded">
                    <div className="text-2xl">🔐</div>
                    <p className="text-sm font-medium">Authentication</p>
                    <p className="text-xs text-muted-foreground">Cloud provider auth</p>
                  </div>
                  <div className="space-y-2 p-3 border rounded">
                    <div className="text-2xl">📁</div>
                    <p className="text-sm font-medium">Resource Creation</p>
                    <p className="text-xs text-muted-foreground">Creating resources</p>
                  </div>
                  <div className="space-y-2 p-3 border rounded">
                    <div className="text-2xl">🔨</div>
                    <p className="text-sm font-medium">Building</p>
                    <p className="text-xs text-muted-foreground">Image building</p>
                  </div>
                  <div className="space-y-2 p-3 border rounded">
                    <div className="text-2xl">📦</div>
                    <p className="text-sm font-medium">Deployment</p>
                    <p className="text-xs text-muted-foreground">Container deployment</p>
                  </div>
                  <div className="space-y-2 p-3 border rounded">
                    <div className="text-2xl">✅</div>
                    <p className="text-sm font-medium">Success</p>
                    <p className="text-xs text-muted-foreground">Completed successfully</p>
                  </div>
                  <div className="space-y-2 p-3 border rounded">
                    <div className="text-2xl">❌</div>
                    <p className="text-sm font-medium">Error</p>
                    <p className="text-xs text-muted-foreground">Deployment failed</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {testResults.length > 0 && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Demo Test Results</CardTitle>
                  <CardDescription>
                    Results from emoji-based deployment demonstrations
                  </CardDescription>
                </div>
                <Button onClick={clearResults} variant="outline" size="sm">
                  Clear Results
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {testResults.map((result, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <p className="font-medium">{result.deploymentId}</p>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          {result.stages && (
                            <span>Stages: {result.stages}</span>
                          )}
                          {result.totalTime && (
                            <span>Duration: {(result.totalTime / 1000).toFixed(1)}s</span>
                          )}
                          {result.reason && (
                            <span>Reason: {result.reason}</span>
                          )}
                        </div>
                      </div>
                      <Badge className={getStatusColor(result.status)}>
                        {result.status === 'success' ? 'Success' : 'Failed'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Demo System Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm">Emoji Status System: Active</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm">Progress Tracking: Enabled</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm">Visual Feedback: Working</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="real" className="space-y-6">
          <RealDeploymentTest />
        </TabsContent>
      </Tabs>
    </div>
  );
}