import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, XCircle, Clock, RefreshCw, AlertCircle } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";

interface PermissionStatus {
  authentication: boolean;
  subscriptionAccess: boolean;
  objectId: string;
  readyForDeployment: boolean;
  lastChecked: string;
  permissionsPropagating: boolean;
  contributorRoleRequired: boolean;
}

export default function AzureMonitor() {
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [deploymentTest, setDeploymentTest] = useState<any>(null);

  const { data: status, refetch, isLoading } = useQuery<PermissionStatus>({
    queryKey: ['/api/azure/permissions/status'],
    refetchInterval: autoRefresh ? 30000 : false,
  });

  const testDeployment = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/azure/test-live-deployment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      return response.json();
    },
    onSuccess: (data) => {
      setDeploymentTest(data);
    }
  });

  const getStatusIcon = (isReady: boolean, isPending: boolean = false) => {
    if (isPending) return <Clock className="h-4 w-4 text-yellow-500" />;
    if (isReady) return <CheckCircle className="h-4 w-4 text-green-500" />;
    return <XCircle className="h-4 w-4 text-red-500" />;
  };

  const getProgressValue = () => {
    if (!status) return 0;
    let progress = 0;
    if (status.authentication) progress += 50;
    if (status.subscriptionAccess) progress += 50;
    return progress;
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Azure Permission Monitor</h1>
          <p className="text-muted-foreground">
            Track Azure role assignment propagation and deployment readiness
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant={autoRefresh ? "default" : "outline"}
            size="sm"
            onClick={() => setAutoRefresh(!autoRefresh)}
          >
            Auto-refresh: {autoRefresh ? "ON" : "OFF"}
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Permission Status
              {status?.readyForDeployment ? (
                <Badge variant="default" className="bg-green-500">Ready</Badge>
              ) : (
                <Badge variant="secondary">Propagating</Badge>
              )}
            </CardTitle>
            <CardDescription>
              Azure role assignments for Object ID: {status?.objectId}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{getProgressValue()}%</span>
              </div>
              <Progress value={getProgressValue()} className="h-2" />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getStatusIcon(status?.authentication || false)}
                  <span className="text-sm">Azure Authentication</span>
                </div>
                <Badge variant={status?.authentication ? "default" : "destructive"}>
                  {status?.authentication ? "Active" : "Failed"}
                </Badge>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getStatusIcon(
                    status?.subscriptionAccess || false,
                    status?.permissionsPropagating
                  )}
                  <span className="text-sm">Subscription Access</span>
                </div>
                <Badge variant={status?.subscriptionAccess ? "default" : "secondary"}>
                  {status?.subscriptionAccess ? "Active" : "Pending"}
                </Badge>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getStatusIcon(status?.readyForDeployment || false)}
                  <span className="text-sm">Deployment Ready</span>
                </div>
                <Badge variant={status?.readyForDeployment ? "default" : "secondary"}>
                  {status?.readyForDeployment ? "Yes" : "No"}
                </Badge>
              </div>
            </div>

            {status?.lastChecked && (
              <p className="text-xs text-muted-foreground">
                Last checked: {new Date(status.lastChecked).toLocaleTimeString()}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Live Deployment Test</CardTitle>
            <CardDescription>
              Test actual Azure resource creation with current permissions
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={() => testDeployment.mutate()}
              disabled={testDeployment.isPending || !status?.authentication}
              className="w-full"
            >
              {testDeployment.isPending ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Testing Deployment...
                </>
              ) : (
                "Test Live Deployment"
              )}
            </Button>

            {deploymentTest && (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  {deploymentTest.success ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-red-500" />
                  )}
                  <span className="text-sm font-medium">
                    {deploymentTest.success ? "Test Successful" : "Test Failed"}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {deploymentTest.message}
                </p>
                {deploymentTest.containerId && (
                  <p className="text-xs text-green-600">
                    Container ID: {deploymentTest.containerId}
                  </p>
                )}
                {deploymentTest.publicIp && (
                  <p className="text-xs text-blue-600">
                    Public IP: {deploymentTest.publicIp}
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {status?.permissionsPropagating && (
        <Card className="border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-950/10">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-yellow-600" />
              <div>
                <p className="font-medium text-yellow-800 dark:text-yellow-200">
                  Permissions Propagating
                </p>
                <p className="text-sm text-yellow-700 dark:text-yellow-300">
                  Azure role assignments typically take 5-30 minutes to become active across all services.
                  The Contributor role has been assigned to Object ID {status.objectId}.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {status?.readyForDeployment && (
        <Card className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950/10">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <p className="font-medium text-green-800 dark:text-green-200">
                  Platform Ready for Deployment
                </p>
                <p className="text-sm text-green-700 dark:text-green-300">
                  Azure permissions are active. You can now deploy infrastructure including
                  containers, databases, storage accounts, and other Azure resources.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}