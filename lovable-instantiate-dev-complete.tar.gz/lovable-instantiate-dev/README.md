# Instantiate.dev - Multi-Cloud Infrastructure Platform

A comprehensive multi-cloud deployment management system with AI-powered assistance.

## Features

- **Multi-Cloud Support**: AWS, Azure, GCP, DigitalOcean, Linode, and more
- **Infrastructure Import**: Terraform, CloudFormation, ARM templates, Kubernetes
- **AI Assistant**: Groq-powered deployment guidance
- **Domain Management**: Namecheap integration
- **Real-time Analytics**: Performance monitoring and cost optimization

## Quick Start

1. Install dependencies:
   ```bash
   npm install
   ```

2. Set up environment variables:
   ```bash
   cp .env.example .env
   # Edit .env with your API keys
   ```

3. Start development server:
   ```bash
   npm run dev
   ```

## Environment Variables

- `DATABASE_URL` - PostgreSQL connection string
- `GROQ_API_KEY` - AI assistant API key
- `NAMECHEAP_API_USER` - Domain management
- `NAMECHEAP_API_KEY` - Domain management
- `NAMECHEAP_USERNAME` - Domain management

## Tech Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Backend**: Node.js + Express
- **Database**: PostgreSQL + Drizzle ORM
- **Styling**: Tailwind CSS + Shadcn/ui
- **State**: TanStack Query
- **Routing**: Wouter

## Project Structure

```
├── client/          # React frontend
├── server/          # Node.js backend  
├── shared/          # Shared types/schemas
└── package.json
```
