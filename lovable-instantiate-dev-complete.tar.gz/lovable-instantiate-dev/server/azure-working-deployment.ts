import https from 'https';
import { URLSearchParams } from 'url';
import fetch from 'node-fetch';

interface AzureDeploymentSpec {
  name: string;
  image: string;
  resourceGroup: string;
  location: string;
  cpu: number;
  memory: number;
  ports: number[];
  environmentVariables?: Record<string, string>;
}

export class AzureWorkingDeployment {
  private credentials = {
    clientId: "abb8ccdc-a48e-4b14-979e-161f4f3072f0",
    clientSecret: "Yam8Q~0ZhFR7r3ALz2DBOFr2qMkHePj4HzwJ1crn",
    tenantId: "4d2858d9-441d-46f0-b085-60e4ca7a5e75",
    subscriptionId: "3e513234-2b8a-4b15-8632-203397fae29f"
  };

  private async getAccessToken(): Promise<string> {
    const tokenUrl = `https://login.microsoftonline.com/${this.credentials.tenantId}/oauth2/v2.0/token`;
    
    const params = new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: this.credentials.clientId,
      client_secret: this.credentials.clientSecret,
      scope: 'https://management.azure.com/.default'
    });

    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: params.toString()
    });

    const data: any = await response.json();
    if (!response.ok) {
      throw new Error(`Failed to get access token: ${JSON.stringify(data)}`);
    }

    return data.access_token;
  }

  private async makeAzureRequest(path: string, method: string = 'GET', body?: any): Promise<any> {
    const token = await this.getAccessToken();
    const url = `https://management.azure.com${path}?api-version=2023-05-01`;

    const response = await fetch(url, {
      method,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: body ? JSON.stringify(body) : undefined
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(`Azure API error: ${response.status} - ${JSON.stringify(data)}`);
    }

    return data;
  }

  async createResourceGroup(name: string, location: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourcegroups/${name}`;
    
    const body = {
      location: location,
      tags: {
        createdBy: 'Instanti8-Platform',
        purpose: 'container-deployment'
      }
    };

    return await this.makeAzureRequest(path, 'PUT', body);
  }

  async deployContainer(spec: AzureDeploymentSpec): Promise<any> {
    // First ensure resource group exists
    try {
      await this.createResourceGroup(spec.resourceGroup, spec.location);
    } catch (error) {
      console.log('Resource group may already exist:', error);
    }

    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${spec.resourceGroup}/providers/Microsoft.ContainerInstance/containerGroups/${spec.name}`;
    
    const containerPorts = spec.ports.map(port => ({ port, protocol: 'TCP' }));
    const ipPorts = spec.ports.map(port => ({ port, protocol: 'TCP' }));

    const body = {
      location: spec.location,
      properties: {
        containers: [{
          name: spec.name,
          properties: {
            image: spec.image,
            ports: containerPorts,
            environmentVariables: Object.entries(spec.environmentVariables || {}).map(([name, value]) => ({
              name,
              value
            })),
            resources: {
              requests: {
                cpu: spec.cpu,
                memoryInGB: spec.memory
              }
            }
          }
        }],
        osType: 'Linux',
        restartPolicy: 'Always',
        ipAddress: {
          type: 'Public',
          ports: ipPorts
        }
      },
      tags: {
        createdBy: 'Instanti8-Platform',
        deploymentTime: new Date().toISOString()
      }
    };

    return await this.makeAzureRequest(path, 'PUT', body);
  }

  async getContainerStatus(resourceGroup: string, containerName: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.ContainerInstance/containerGroups/${containerName}`;
    return await this.makeAzureRequest(path);
  }

  async testFullDeployment(): Promise<any> {
    const spec: AzureDeploymentSpec = {
      name: 'instanti8-test-container',
      image: 'mcr.microsoft.com/azuredocs/aci-helloworld',
      resourceGroup: 'instanti8-test-rg',
      location: 'eastus',
      cpu: 1,
      memory: 1.5,
      ports: [80],
      environmentVariables: {
        'DEPLOYMENT_TYPE': 'test',
        'PLATFORM': 'azure-container-instances',
        'TIMESTAMP': new Date().toISOString()
      }
    };

    try {
      console.log('Starting Azure Container Instance deployment...');
      const deployment = await this.deployContainer(spec);
      
      console.log('Deployment initiated, checking status...');
      
      // Wait a moment then check status
      await new Promise(resolve => setTimeout(resolve, 5000));
      const status = await this.getContainerStatus(spec.resourceGroup, spec.name);
      
      return {
        success: true,
        deployment,
        status,
        url: status.properties?.ipAddress?.fqdn ? `http://${status.properties.ipAddress.fqdn}` : null
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message
      };
    }
  }
}

const azureWorkingDeployment = new AzureWorkingDeployment();
export { azureWorkingDeployment };