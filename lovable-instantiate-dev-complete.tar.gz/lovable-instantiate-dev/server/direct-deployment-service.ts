import fs from 'fs/promises';
import path from 'path';

interface DirectDeploymentSpec {
  name: string;
  content: string;
  type: 'html' | 'node' | 'python';
  environmentVariables?: Record<string, string>;
}

interface DirectDeploymentResult {
  success: boolean;
  deploymentId: string;
  url?: string;
  path?: string;
  error?: string;
}

export class DirectDeploymentService {
  private deploymentsPath: string;

  constructor() {
    this.deploymentsPath = path.join(process.cwd(), 'live-deployments');
  }

  async deployApplication(spec: DirectDeploymentSpec): Promise<DirectDeploymentResult> {
    const deploymentId = `${spec.name}-${Date.now()}`;
    const deploymentPath = path.join(this.deploymentsPath, deploymentId);

    try {
      // Create deployment directory
      await fs.mkdir(deploymentPath, { recursive: true });

      // Create application files based on type
      if (spec.type === 'html') {
        await this.createHtmlDeployment(deploymentPath, spec);
      } else if (spec.type === 'node') {
        await this.createNodeDeployment(deploymentPath, spec);
      } else if (spec.type === 'python') {
        await this.createPythonDeployment(deploymentPath, spec);
      }

      // Create deployment manifest
      const manifest = {
        id: deploymentId,
        name: spec.name,
        type: spec.type,
        createdAt: new Date().toISOString(),
        environmentVariables: spec.environmentVariables || {},
        status: 'deployed'
      };

      await fs.writeFile(
        path.join(deploymentPath, 'deployment.json'),
        JSON.stringify(manifest, null, 2)
      );

      return {
        success: true,
        deploymentId,
        url: `http://localhost:5000/deployments/${deploymentId}`,
        path: deploymentPath
      };

    } catch (error: any) {
      return {
        success: false,
        deploymentId,
        error: `Deployment failed: ${error.message}`
      };
    }
  }

  private async createHtmlDeployment(deploymentPath: string, spec: DirectDeploymentSpec) {
    const htmlContent = spec.content || `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${spec.name}</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 40px; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
        }
        .container { 
            max-width: 800px; 
            margin: 0 auto; 
            background: rgba(255,255,255,0.1); 
            padding: 40px; 
            border-radius: 12px; 
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }
        .status { 
            background: rgba(76, 175, 80, 0.2); 
            padding: 20px; 
            border-radius: 8px; 
            margin: 20px 0; 
            border: 1px solid rgba(76, 175, 80, 0.3);
        }
        .info { 
            background: rgba(33, 150, 243, 0.2); 
            padding: 15px; 
            border-radius: 8px; 
            margin: 10px 0; 
            border: 1px solid rgba(33, 150, 243, 0.3);
        }
        h1 { margin-top: 0; }
        .deployment-id { 
            font-family: monospace; 
            background: rgba(0,0,0,0.2); 
            padding: 4px 8px; 
            border-radius: 4px; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Live Deployment: ${spec.name}</h1>
        <div class="status">
            <strong>Status:</strong> Successfully deployed and running
        </div>
        <div class="info">
            <strong>Application:</strong> ${spec.name}<br>
            <strong>Type:</strong> Static HTML Application<br>
            <strong>Deployed:</strong> ${new Date().toLocaleString()}<br>
            <strong>Platform:</strong> Instanti8 Direct Deployment
        </div>
        <p>This application is live and accessible. The deployment was successful and the application is now running.</p>
        <div class="info">
            <strong>Environment Variables:</strong><br>
            ${Object.entries(spec.environmentVariables || {}).map(([key, value]) => 
              `<code>${key}=${value}</code>`
            ).join('<br>') || 'None configured'}
        </div>
    </div>
</body>
</html>`;

    await fs.writeFile(path.join(deploymentPath, 'index.html'), htmlContent);
  }

  private async createNodeDeployment(deploymentPath: string, spec: DirectDeploymentSpec) {
    const packageJson = {
      name: spec.name,
      version: "1.0.0",
      description: "Deployed via Instanti8 Platform",
      main: "server.js",
      scripts: {
        start: "node server.js"
      },
      dependencies: {
        express: "^4.18.0"
      }
    };

    const serverJs = spec.content || `
const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.static('public'));

app.get('/', (req, res) => {
  res.send(\`
<!DOCTYPE html>
<html>
<head>
    <title>${spec.name}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f8f9fa; }
        .container { max-width: 600px; margin: 0 auto; background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .status { background: #d4edda; padding: 20px; border-radius: 4px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Node.js Application: ${spec.name}</h1>
        <div class="status">Status: Running successfully</div>
        <p>Deployment time: \${new Date().toISOString()}</p>
        <p>Environment: \${process.env.NODE_ENV || 'development'}</p>
    </div>
</body>
</html>
  \`);
});

app.listen(port, () => {
  console.log(\`${spec.name} running on port \${port}\`);
});
`;

    await fs.writeFile(path.join(deploymentPath, 'package.json'), JSON.stringify(packageJson, null, 2));
    await fs.writeFile(path.join(deploymentPath, 'server.js'), serverJs);
    await fs.writeFile(path.join(deploymentPath, 'index.html'), `
<!DOCTYPE html>
<html>
<head><title>${spec.name}</title></head>
<body>
    <h1>Node.js Application Deployed</h1>
    <p>Application: ${spec.name}</p>
    <p>Status: Ready to run</p>
    <p>Run with: <code>npm start</code></p>
</body>
</html>
`);
  }

  private async createPythonDeployment(deploymentPath: string, spec: DirectDeploymentSpec) {
    const appPy = spec.content || `
from http.server import HTTPServer, SimpleHTTPRequestHandler
import os

class CustomHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>${spec.name}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; background: #f8f9fa; }}
        .container {{ max-width: 600px; margin: 0 auto; background: white; padding: 40px; border-radius: 8px; }}
        .status {{ background: #d4edda; padding: 20px; border-radius: 4px; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Python Application: ${spec.name}</h1>
        <div class="status">Status: Running successfully</div>
        <p>Python server deployed via Instanti8</p>
    </div>
</body>
</html>
            """
            self.wfile.write(html.encode())
        else:
            super().do_GET()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8000))
    server = HTTPServer(('localhost', port), CustomHandler)
    print(f'${spec.name} running on port {port}')
    server.serve_forever()
`;

    const requirementsTxt = `# Requirements for ${spec.name}
# No additional dependencies required for basic HTTP server
`;

    await fs.writeFile(path.join(deploymentPath, 'app.py'), appPy);
    await fs.writeFile(path.join(deploymentPath, 'requirements.txt'), requirementsTxt);
    await fs.writeFile(path.join(deploymentPath, 'index.html'), `
<!DOCTYPE html>
<html>
<head><title>${spec.name}</title></head>
<body>
    <h1>Python Application Deployed</h1>
    <p>Application: ${spec.name}</p>
    <p>Status: Ready to run</p>
    <p>Run with: <code>python app.py</code></p>
</body>
</html>
`);
  }

  async listDeployments(): Promise<any[]> {
    try {
      const deployments = [];
      const files = await fs.readdir(this.deploymentsPath);
      
      for (const file of files) {
        const deploymentPath = path.join(this.deploymentsPath, file);
        const manifestPath = path.join(deploymentPath, 'deployment.json');
        
        try {
          const manifestContent = await fs.readFile(manifestPath, 'utf-8');
          const manifest = JSON.parse(manifestContent);
          deployments.push({
            ...manifest,
            url: `http://localhost:5000/deployments/${file}`
          });
        } catch (error) {
          // Skip invalid deployments
        }
      }
      
      return deployments;
    } catch (error) {
      return [];
    }
  }

  async getDeployment(deploymentId: string): Promise<any | null> {
    try {
      const deploymentPath = path.join(this.deploymentsPath, deploymentId);
      const manifestPath = path.join(deploymentPath, 'deployment.json');
      
      const manifestContent = await fs.readFile(manifestPath, 'utf-8');
      const manifest = JSON.parse(manifestContent);
      
      return {
        ...manifest,
        url: `http://localhost:5000/deployments/${deploymentId}`,
        path: deploymentPath
      };
    } catch (error) {
      return null;
    }
  }

  async deleteDeployment(deploymentId: string): Promise<boolean> {
    try {
      const deploymentPath = path.join(this.deploymentsPath, deploymentId);
      await fs.rm(deploymentPath, { recursive: true, force: true });
      return true;
    } catch (error) {
      return false;
    }
  }
}

export const directDeploymentService = new DirectDeploymentService();