// Azure service temporarily disabled for deployment
export function getAzureService() {
  return {
    createContainer: async (spec: any) => {
      return {
        name: spec.name,
        status: 'simulated',
        message: 'Azure service temporarily disabled for deployment'
      };
    }
  };
}