import { URLSearchParams } from 'url';
import fetch from 'node-fetch';

interface AzureContainerAppRequest {
  name: string;
  code: string;
  codeType: 'javascript' | 'python' | 'html';
  resourceGroup: string;
  location: string;
  environmentVariables?: Record<string, string>;
}

export class AzureContainerApps {
  private credentials = {
    clientId: "abb8ccdc-a48e-4b14-979e-161f4f3072f0",
    clientSecret: "Yam8Q~0ZhFR7r3ALz2DBOFr2qMkHePj4HzwJ1crn", 
    tenantId: "4d2858d9-441d-46f0-b085-60e4ca7a5e75",
    subscriptionId: "3e513234-2b8a-4b15-8632-203397fae29f"
  };

  private async getAccessToken(): Promise<string> {
    const tokenUrl = `https://login.microsoftonline.com/${this.credentials.tenantId}/oauth2/v2.0/token`;
    
    const params = new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: this.credentials.clientId,
      client_secret: this.credentials.clientSecret,
      scope: 'https://management.azure.com/.default'
    });

    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });

    const data: any = await response.json();
    if (!response.ok) {
      throw new Error(`Azure authentication failed: ${JSON.stringify(data)}`);
    }

    return data.access_token;
  }

  private async makeAzureRequest(path: string, method: string = 'GET', body: any = null, apiVersion: string = '2023-05-01'): Promise<any> {
    const token = await this.getAccessToken();
    const url = `https://management.azure.com${path}?api-version=${apiVersion}`;
    
    const headers: Record<string, string> = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    const options: any = {
      method,
      headers,
      ...(body && { body: JSON.stringify(body) })
    };

    const response = await fetch(url, options as any);
    const responseData = await response.text();
    
    if (!response.ok) {
      throw new Error(`Azure API error: ${response.status} - ${responseData}`);
    }

    return responseData ? JSON.parse(responseData) : {};
  }

  async deployContainerApp(spec: AzureContainerAppRequest): Promise<any> {
    // 1. Ensure resource group exists
    await this.ensureResourceGroup(spec.resourceGroup, spec.location);

    // 2. Create Container Apps Environment
    const environmentName = `${spec.name}-env`;
    await this.createContainerAppsEnvironment(spec.resourceGroup, environmentName, spec.location);

    // 3. Create the Container App with user code
    const containerApp = await this.createContainerApp(spec, environmentName);

    return {
      name: spec.name,
      resourceGroup: spec.resourceGroup,
      url: `https://${spec.name}.${spec.location}.azurecontainerapps.io`,
      status: 'Deployed',
      provider: 'azure-container-apps',
      codeDeployed: true
    };
  }

  private async ensureResourceGroup(resourceGroup: string, location: string): Promise<void> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}`;
    
    try {
      await this.makeAzureRequest(path);
    } catch (error) {
      const body = {
        location: location,
        tags: {
          createdBy: 'Instanti8-Platform',
          purpose: 'container-app-deployment'
        }
      };
      
      await this.makeAzureRequest(path, 'PUT', body, '2021-04-01');
    }
  }

  private async createContainerAppsEnvironment(resourceGroup: string, environmentName: string, location: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.App/managedEnvironments/${environmentName}`;
    
    try {
      return await this.makeAzureRequest(path);
    } catch (error) {
      const body = {
        location: location,
        properties: {
          appLogsConfiguration: {
            destination: 'log-analytics'
          }
        }
      };
      
      return await this.makeAzureRequest(path, 'PUT', body);
    }
  }

  private async createContainerApp(spec: AzureContainerAppRequest, environmentName: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${spec.resourceGroup}/providers/Microsoft.App/containerApps/${spec.name}`;
    
    // Create startup script based on code type
    let containerImage = 'mcr.microsoft.com/azuredocs/containerapps-helloworld:latest';
    let startupCommand: string[] = [];
    
    if (spec.codeType === 'javascript') {
      containerImage = 'node:18-alpine';
      // Create a script that installs dependencies and runs user code
      const script = `
echo '${JSON.stringify({
  name: spec.name,
  version: '1.0.0',
  main: 'app.js',
  dependencies: { express: '^4.18.0' }
})}' > package.json && 
npm install && 
echo '${Buffer.from(spec.code).toString('base64')}' | base64 -d > app.js && 
node app.js
      `.trim();
      
      startupCommand = ['sh', '-c', script];
    }

    const body = {
      location: spec.location,
      properties: {
        managedEnvironmentId: `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${spec.resourceGroup}/providers/Microsoft.App/managedEnvironments/${environmentName}`,
        configuration: {
          ingress: {
            external: true,
            targetPort: spec.codeType === 'javascript' ? 3000 : 80,
            traffic: [{
              weight: 100,
              latestRevision: true
            }]
          }
        },
        template: {
          containers: [{
            name: spec.name,
            image: containerImage,
            ...(startupCommand.length > 0 && { command: startupCommand }),
            env: Object.entries(spec.environmentVariables || {}).map(([name, value]) => ({
              name, value
            })),
            resources: {
              cpu: 0.5,
              memory: '1Gi'
            }
          }],
          scale: {
            minReplicas: 1,
            maxReplicas: 3
          }
        }
      }
    };

    return await this.makeAzureRequest(path, 'PUT', body);
  }

  async getContainerAppStatus(resourceGroup: string, appName: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.App/containerApps/${appName}`;
    return await this.makeAzureRequest(path);
  }

  async listContainerApps(resourceGroup?: string): Promise<any[]> {
    let path: string;
    
    if (resourceGroup) {
      path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.App/containerApps`;
    } else {
      path = `/subscriptions/${this.credentials.subscriptionId}/providers/Microsoft.App/containerApps`;
    }
    
    const result = await this.makeAzureRequest(path);
    return result.value || [];
  }
}

export const azureContainerApps = new AzureContainerApps();