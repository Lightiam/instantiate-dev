import { aiChatService } from './ai-chat-service';
import { deploymentVerificationService } from './deployment-verification-service';

interface DeploymentIssueContext {
  userMessage: string;
  deploymentId?: string;
  provider: 'azure' | 'aws' | 'gcp';
  expectedResources?: any[];
  errorLogs?: string;
}

interface SmartDiagnosis {
  rootCause: string;
  technicalDetails: string;
  userFriendlyExplanation: string;
  immediateActions: string[];
  longTermSolutions: string[];
  estimatedResolution: string;
  monitoringSteps: string[];
}

export class SmartDeploymentAssistant {
  async diagnoseDeploymentIssue(context: DeploymentIssueContext): Promise<SmartDiagnosis> {
    try {
      // Check provider-specific status
      const providerStatus = await this.checkProviderStatus(context.provider);
      
      // Verify actual resources if deployment ID provided
      let verification;
      if (context.deploymentId && context.expectedResources) {
        verification = await deploymentVerificationService.verifyDeployment(
          context.deploymentId,
          context.provider,
          context.expectedResources
        );
      }

      // Get AI analysis
      const aiAnalysis = await this.getAIAnalysis(context, providerStatus, verification);

      // Determine root cause
      const diagnosis = await this.determineDiagnosis(context, providerStatus, verification, aiAnalysis);

      return diagnosis;
    } catch (error: any) {
      return {
        rootCause: 'System Analysis Error',
        technicalDetails: error.message,
        userFriendlyExplanation: 'Unable to complete deployment analysis due to system error.',
        immediateActions: ['Check system logs', 'Retry analysis'],
        longTermSolutions: ['Contact support if error persists'],
        estimatedResolution: 'Unknown',
        monitoringSteps: ['Monitor system status']
      };
    }
  }

  private async checkProviderStatus(provider: string): Promise<any> {
    switch (provider) {
      case 'azure':
        try {
          const { azureDiagnostic } = await import('./azure-diagnostic');
          const results = await azureDiagnostic.runCompleteDiagnostic();
          
          const authTest = results.find(r => r.test === 'Azure Authentication');
          const subTest = results.find(r => r.test === 'Subscription Access');
          
          return {
            authenticated: authTest?.status === 'success',
            hasAccess: subTest?.status === 'success',
            permissionsPropagating: authTest?.status === 'success' && subTest?.status === 'error',
            objectId: '062b497a-b94c-4381-8bab-052e50815534',
            errorDetails: subTest?.message,
            diagnostics: results
          };
        } catch (error: any) {
          return {
            authenticated: false,
            hasAccess: false,
            error: error.message
          };
        }

      case 'gcp':
        try {
          const projectId = process.env.GCP_PROJECT_ID;
          const serviceKey = process.env.GCP_SERVICE_ACCOUNT_KEY;
          
          return {
            configured: !!(projectId && serviceKey),
            projectId: projectId?.substring(0, 10) + '...' || 'not configured',
            hasServiceKey: !!serviceKey
          };
        } catch (error: any) {
          return { configured: false, error: error.message };
        }

      case 'aws':
        // AWS status check would go here
        return { configured: false, message: 'AWS integration not yet implemented' };

      default:
        return { error: 'Unknown provider' };
    }
  }

  private async getAIAnalysis(context: DeploymentIssueContext, providerStatus: any, verification?: any): Promise<string> {
    try {
      const analysisPrompt = `Analyze this deployment issue:

User Message: ${context.userMessage}
Provider: ${context.provider}
Provider Status: ${JSON.stringify(providerStatus, null, 2)}
${verification ? `Verification Results: ${JSON.stringify(verification, null, 2)}` : ''}
${context.errorLogs ? `Error Logs: ${context.errorLogs}` : ''}

Provide a concise technical analysis of the root cause and recommended solutions.`;

      const deploymentContext = {
        userQuery: analysisPrompt,
        provider: context.provider,
        resourceType: 'deployment-diagnosis',
        errorLogs: context.errorLogs
      };

      const aiResponse = await aiChatService.generateResponse(deploymentContext);
      return aiResponse.message;
    } catch (error: any) {
      return `AI analysis unavailable: ${error.message}`;
    }
  }

  private async determineDiagnosis(
    context: DeploymentIssueContext,
    providerStatus: any,
    verification?: any,
    aiAnalysis?: string
  ): Promise<SmartDiagnosis> {
    
    // Azure-specific diagnosis
    if (context.provider === 'azure') {
      if (providerStatus.permissionsPropagating) {
        return {
          rootCause: 'Azure Role Assignment Propagation Delay',
          technicalDetails: `Authentication successful but subscription access denied. Azure role assignments for Object ID ${providerStatus.objectId} are still propagating across Microsoft's global infrastructure.`,
          userFriendlyExplanation: 'Your deployments appear successful but no real infrastructure is created because Azure is still activating your permissions. This is normal and typically takes 5-30 minutes.',
          immediateActions: [
            'Monitor permission status at the Azure Monitor dashboard',
            'Wait for role assignment propagation to complete',
            'Avoid attempting new deployments until permissions are active'
          ],
          longTermSolutions: [
            'Once permissions are active, retry your deployments',
            'Set up monitoring alerts for permission status',
            'Consider using Azure CLI for direct verification'
          ],
          estimatedResolution: '5-30 minutes',
          monitoringSteps: [
            'Check /azure-monitor for real-time permission status',
            'Test simple container deployment when permissions activate',
            'Verify resource creation in Azure portal'
          ]
        };
      }

      if (!providerStatus.authenticated) {
        return {
          rootCause: 'Azure Authentication Failure',
          technicalDetails: `Azure credentials invalid or expired: ${providerStatus.errorDetails || 'Unknown authentication error'}`,
          userFriendlyExplanation: 'Cannot connect to Azure with the provided credentials. This prevents any resource deployment.',
          immediateActions: [
            'Verify Azure credentials in platform settings',
            'Check client ID, client secret, and tenant ID',
            'Ensure credentials have not expired'
          ],
          longTermSolutions: [
            'Regenerate Azure service principal credentials',
            'Verify correct subscription access',
            'Test credentials using Azure CLI'
          ],
          estimatedResolution: 'Immediate after credential correction',
          monitoringSteps: [
            'Test Azure connection after credential update',
            'Monitor authentication status'
          ]
        };
      }
    }

    // GCP-specific diagnosis
    if (context.provider === 'gcp') {
      if (!providerStatus.configured) {
        return {
          rootCause: 'Google Cloud Platform Not Configured',
          technicalDetails: 'Missing GCP_PROJECT_ID or GCP_SERVICE_ACCOUNT_KEY environment variables',
          userFriendlyExplanation: 'Google Cloud Platform credentials are not configured, preventing any GCP resource deployment.',
          immediateActions: [
            'Obtain GCP service account key from Google Cloud Console',
            'Configure GCP_PROJECT_ID and GCP_SERVICE_ACCOUNT_KEY',
            'Verify service account has necessary permissions'
          ],
          longTermSolutions: [
            'Set up proper IAM roles for service account',
            'Enable required GCP APIs for your project',
            'Test GCP connectivity'
          ],
          estimatedResolution: 'Immediate after credential configuration',
          monitoringSteps: [
            'Test GCP connection after setup',
            'Monitor GCP resource creation'
          ]
        };
      }
    }

    // Generic deployment verification failure
    if (verification && verification.status === 'not_found') {
      return {
        rootCause: 'Deployment Success But No Resources Found',
        technicalDetails: `Deployment reported success but verification found no matching resources. This typically indicates permission issues or resource creation in unexpected locations.`,
        userFriendlyExplanation: 'The deployment process completed without errors, but no actual infrastructure was created. This usually means permission issues or configuration problems.',
        immediateActions: [
          'Check cloud provider console directly',
          'Verify correct region/subscription/project selection',
          'Review deployment logs for hidden errors'
        ],
        longTermSolutions: [
          'Implement more robust deployment verification',
          'Add resource tagging for better tracking',
          'Set up monitoring for successful deployments'
        ],
        estimatedResolution: 'Depends on root cause',
        monitoringSteps: [
          'Monitor cloud provider console',
          'Set up alerts for resource creation',
          'Verify deployment pipeline integrity'
        ]
      };
    }

    // Fallback diagnosis
    return {
      rootCause: 'Unknown Deployment Issue',
      technicalDetails: aiAnalysis || 'Unable to determine specific cause',
      userFriendlyExplanation: 'The deployment system is experiencing an issue that requires further investigation.',
      immediateActions: [
        'Check system status and logs',
        'Verify cloud provider connectivity',
        'Review recent configuration changes'
      ],
      longTermSolutions: [
        'Contact support with deployment details',
        'Review system configuration',
        'Implement enhanced monitoring'
      ],
      estimatedResolution: 'Unknown - requires investigation',
      monitoringSteps: [
        'Monitor system logs',
        'Check cloud provider status',
        'Track deployment success rates'
      ]
    };
  }

  async generateUserFriendlyResponse(diagnosis: SmartDiagnosis, userMessage: string): Promise<{
    message: string;
    suggestions: string[];
    nextSteps: string[];
  }> {
    const response = `I've analyzed your deployment issue: "${userMessage}"

**What's happening**: ${diagnosis.userFriendlyExplanation}

**Root cause**: ${diagnosis.rootCause}

**Expected resolution time**: ${diagnosis.estimatedResolution}

**Why this happens**: ${diagnosis.technicalDetails}

You can monitor the situation and track progress using the platform's monitoring tools.`;

    return {
      message: response,
      suggestions: diagnosis.immediateActions,
      nextSteps: diagnosis.monitoringSteps
    };
  }
}

export const smartDeploymentAssistant = new SmartDeploymentAssistant();