import https from 'https';

interface ServicePrincipalCreationRequest {
  displayName: string;
  subscriptionId: string;
  roleDefinitionName: string;
}

interface ServicePrincipalResponse {
  applicationId: string;
  objectId: string;
  tenantId: string;
  clientSecret: string;
  subscriptionId: string;
  expirationDate: string;
}

export class AzureServicePrincipalManager {
  private tenantId: string;
  
  constructor() {
    this.tenantId = process.env.AZURE_TENANT_ID || '';
  }

  async createServicePrincipal(request: ServicePrincipalCreationRequest): Promise<ServicePrincipalResponse> {
    try {
      // Step 1: Get admin access token (requires user to authenticate)
      const adminToken = await this.getAdminAccessToken();
      
      // Step 2: Create application registration
      const application = await this.createApplicationRegistration(adminToken, request.displayName);
      
      // Step 3: Create service principal
      const servicePrincipal = await this.createServicePrincipal(adminToken, application.appId);
      
      // Step 4: Create client secret
      const clientSecret = await this.createClientSecret(adminToken, application.appId);
      
      // Step 5: Assign role to service principal
      await this.assignRole(adminToken, servicePrincipal.objectId, request.subscriptionId, request.roleDefinitionName);
      
      return {
        applicationId: application.appId,
        objectId: servicePrincipal.objectId,
        tenantId: this.tenantId,
        clientSecret: clientSecret.secretText,
        subscriptionId: request.subscriptionId,
        expirationDate: clientSecret.endDateTime
      };
    } catch (error: any) {
      throw new Error(`Service principal creation failed: ${error.message}`);
    }
  }

  private async getAdminAccessToken(): Promise<string> {
    // This would require user authentication flow
    throw new Error('Admin authentication required - implement OAuth flow');
  }

  private async createApplicationRegistration(token: string, displayName: string): Promise<any> {
    const requestBody = JSON.stringify({
      displayName: displayName,
      signInAudience: 'AzureADMyOrg'
    });

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'graph.microsoft.com',
        port: 443,
        path: '/v1.0/applications',
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Content-Length': requestBody.length
        }
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 201) {
            resolve(JSON.parse(data));
          } else {
            reject(new Error(`Failed to create application: ${res.statusCode} - ${data}`));
          }
        });
      });

      req.on('error', reject);
      req.write(requestBody);
      req.end();
    });
  }

  private async createServicePrincipal(token: string, appId: string): Promise<any> {
    const requestBody = JSON.stringify({
      appId: appId
    });

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'graph.microsoft.com',
        port: 443,
        path: '/v1.0/servicePrincipals',
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Content-Length': requestBody.length
        }
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 201) {
            resolve(JSON.parse(data));
          } else {
            reject(new Error(`Failed to create service principal: ${res.statusCode} - ${data}`));
          }
        });
      });

      req.on('error', reject);
      req.write(requestBody);
      req.end();
    });
  }

  private async createClientSecret(token: string, appId: string): Promise<any> {
    const requestBody = JSON.stringify({
      passwordCredential: {
        displayName: 'Instanti8 Deployment Key',
        endDateTime: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString() // 1 year
      }
    });

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'graph.microsoft.com',
        port: 443,
        path: `/v1.0/applications/${appId}/addPassword`,
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Content-Length': requestBody.length
        }
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 200) {
            resolve(JSON.parse(data));
          } else {
            reject(new Error(`Failed to create client secret: ${res.statusCode} - ${data}`));
          }
        });
      });

      req.on('error', reject);
      req.write(requestBody);
      req.end();
    });
  }

  private async assignRole(token: string, principalId: string, subscriptionId: string, roleDefinitionName: string): Promise<void> {
    const roleAssignmentId = this.generateGuid();
    const scope = `/subscriptions/${subscriptionId}`;
    const roleDefinitionId = `/subscriptions/${subscriptionId}/providers/Microsoft.Authorization/roleDefinitions/b24988ac-6180-42a0-ab88-20f7382dd24c`; // Contributor role

    const requestBody = JSON.stringify({
      properties: {
        roleDefinitionId: roleDefinitionId,
        principalId: principalId,
        principalType: 'ServicePrincipal'
      }
    });

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'management.azure.com',
        port: 443,
        path: `/subscriptions/${subscriptionId}/providers/Microsoft.Authorization/roleAssignments/${roleAssignmentId}?api-version=2022-04-01`,
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Content-Length': requestBody.length
        }
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve();
          } else {
            reject(new Error(`Failed to assign role: ${res.statusCode} - ${data}`));
          }
        });
      });

      req.on('error', reject);
      req.write(requestBody);
      req.end();
    });
  }

  private generateGuid(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  async validateExistingCredentials(): Promise<{
    isValid: boolean;
    applicationExists: boolean;
    hasSubscriptionAccess: boolean;
    details: string;
  }> {
    try {
      const clientId = process.env.AZURE_CLIENT_ID;
      const clientSecret = process.env.AZURE_CLIENT_SECRET;
      const tenantId = process.env.AZURE_TENANT_ID;
      const subscriptionId = process.env.AZURE_SUBSCRIPTION_ID;

      if (!clientId || !clientSecret || !tenantId || !subscriptionId) {
        return {
          isValid: false,
          applicationExists: false,
          hasSubscriptionAccess: false,
          details: 'Missing required environment variables'
        };
      }

      // Test authentication
      const token = await this.getServicePrincipalToken(clientId, clientSecret, tenantId);
      
      // Test subscription access
      const hasAccess = await this.testSubscriptionAccess(token, subscriptionId);
      
      return {
        isValid: hasAccess,
        applicationExists: true,
        hasSubscriptionAccess: hasAccess,
        details: hasAccess ? 'Credentials valid' : 'Application exists but lacks subscription permissions'
      };
    } catch (error: any) {
      if (error.message.includes('700016')) {
        return {
          isValid: false,
          applicationExists: false,
          hasSubscriptionAccess: false,
          details: 'Application not found in directory'
        };
      }
      
      return {
        isValid: false,
        applicationExists: false,
        hasSubscriptionAccess: false,
        details: error.message
      };
    }
  }

  private async getServicePrincipalToken(clientId: string, clientSecret: string, tenantId: string): Promise<string> {
    const postData = `client_id=${encodeURIComponent(clientId)}&client_secret=${encodeURIComponent(clientSecret)}&scope=${encodeURIComponent('https://management.azure.com/.default')}&grant_type=client_credentials`;

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'login.microsoftonline.com',
        port: 443,
        path: `/${tenantId}/oauth2/v2.0/token`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': postData.length
        }
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
          try {
            const response = JSON.parse(data);
            if (response.access_token) {
              resolve(response.access_token);
            } else {
              reject(new Error(`Token acquisition failed: ${data}`));
            }
          } catch (error) {
            reject(new Error(`Token parsing failed: ${data}`));
          }
        });
      });

      req.on('error', reject);
      req.write(postData);
      req.end();
    });
  }

  private async testSubscriptionAccess(token: string, subscriptionId: string): Promise<boolean> {
    return new Promise((resolve) => {
      const options = {
        hostname: 'management.azure.com',
        port: 443,
        path: `/subscriptions/${subscriptionId}?api-version=2020-01-01`,
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      };

      const req = https.request(options, (res) => {
        resolve(res.statusCode === 200);
      });

      req.on('error', () => resolve(false));
      req.end();
    });
  }
}

export const azureServicePrincipalManager = new AzureServicePrincipalManager();