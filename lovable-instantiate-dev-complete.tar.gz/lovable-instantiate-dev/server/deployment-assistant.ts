interface DeploymentStatus {
  stage: string;
  emoji: string;
  message: string;
  timestamp: string;
  duration?: number;
  details?: string;
}

interface DeploymentProgress {
  deploymentId: string;
  provider: 'azure' | 'replit' | 'aws' | 'gcp';
  status: 'pending' | 'running' | 'success' | 'failed' | 'cancelled';
  currentStage: string;
  stages: DeploymentStatus[];
  startTime: string;
  endTime?: string;
  totalDuration?: number;
  metadata?: Record<string, any>;
}

export class DeploymentAssistant {
  private deployments = new Map<string, DeploymentProgress>();
  private stageEmojis: Record<string, string> = {
    // Initialization stages
    'initializing': '🚀',
    'validating': '🔍',
    'authenticating': '🔐',
    'preparing': '📋',
    
    // Resource stages
    'creating-resource-group': '📁',
    'configuring-network': '🌐',
    'setting-up-storage': '💾',
    'preparing-environment': '⚙️',
    
    // Deployment stages
    'building-image': '🔨',
    'pushing-image': '📤',
    'deploying-container': '📦',
    'starting-services': '▶️',
    'configuring-dns': '🌍',
    'setting-up-ssl': '🔒',
    
    // Verification stages
    'health-checking': '🩺',
    'running-tests': '🧪',
    'verifying-deployment': '✅',
    'monitoring-setup': '📊',
    
    // Completion stages
    'deployment-complete': '🎉',
    'cleanup': '🧹',
    'rollback': '⏪',
    
    // Error stages
    'error': '❌',
    'warning': '⚠️',
    'retry': '🔄',
    'timeout': '⏰',
    'cancelled': '🛑'
  };

  private stageMessages: Record<string, string> = {
    'initializing': 'Starting deployment process',
    'validating': 'Validating deployment configuration',
    'authenticating': 'Authenticating with cloud provider',
    'preparing': 'Preparing deployment resources',
    'creating-resource-group': 'Creating resource group',
    'configuring-network': 'Setting up network configuration',
    'setting-up-storage': 'Configuring storage resources',
    'preparing-environment': 'Preparing runtime environment',
    'building-image': 'Building container image',
    'pushing-image': 'Pushing image to registry',
    'deploying-container': 'Deploying container instance',
    'starting-services': 'Starting application services',
    'configuring-dns': 'Configuring DNS settings',
    'setting-up-ssl': 'Setting up SSL certificates',
    'health-checking': 'Performing health checks',
    'running-tests': 'Running deployment tests',
    'verifying-deployment': 'Verifying deployment status',
    'monitoring-setup': 'Setting up monitoring',
    'deployment-complete': 'Deployment completed successfully',
    'cleanup': 'Cleaning up temporary resources',
    'rollback': 'Rolling back deployment',
    'error': 'Deployment encountered an error',
    'warning': 'Deployment warning detected',
    'retry': 'Retrying failed operation',
    'timeout': 'Operation timed out',
    'cancelled': 'Deployment was cancelled'
  };

  startDeployment(
    deploymentId: string, 
    provider: 'azure' | 'replit' | 'aws' | 'gcp',
    metadata?: Record<string, any>
  ): void {
    const deployment: DeploymentProgress = {
      deploymentId,
      provider,
      status: 'pending',
      currentStage: 'initializing',
      stages: [],
      startTime: new Date().toISOString(),
      metadata: metadata || {}
    };

    this.deployments.set(deploymentId, deployment);
    this.addStage(deploymentId, 'initializing');
  }

  addStage(
    deploymentId: string, 
    stage: string, 
    customMessage?: string,
    details?: string
  ): void {
    const deployment = this.deployments.get(deploymentId);
    if (!deployment) return;

    // Mark previous stage as completed
    if (deployment.stages.length > 0) {
      const lastStage = deployment.stages[deployment.stages.length - 1];
      if (!lastStage.duration) {
        lastStage.duration = Date.now() - new Date(lastStage.timestamp).getTime();
      }
    }

    const stageStatus: DeploymentStatus = {
      stage,
      emoji: this.stageEmojis[stage] || '📋',
      message: customMessage || this.stageMessages[stage] || `Processing ${stage}`,
      timestamp: new Date().toISOString(),
      details
    };

    deployment.stages.push(stageStatus);
    deployment.currentStage = stage;
    
    // Update deployment status based on stage
    if (stage === 'error' || stage === 'timeout') {
      deployment.status = 'failed';
    } else if (stage === 'cancelled') {
      deployment.status = 'cancelled';
    } else if (stage === 'deployment-complete') {
      deployment.status = 'success';
    } else {
      deployment.status = 'running';
    }

    this.deployments.set(deploymentId, deployment);
  }

  completeDeployment(
    deploymentId: string, 
    success: boolean, 
    finalMessage?: string
  ): void {
    const deployment = this.deployments.get(deploymentId);
    if (!deployment) return;

    // Complete current stage
    if (deployment.stages.length > 0) {
      const lastStage = deployment.stages[deployment.stages.length - 1];
      if (!lastStage.duration) {
        lastStage.duration = Date.now() - new Date(lastStage.timestamp).getTime();
      }
    }

    // Add completion stage
    const completionStage = success ? 'deployment-complete' : 'error';
    this.addStage(
      deploymentId, 
      completionStage,
      finalMessage || (success ? 'Deployment completed successfully' : 'Deployment failed')
    );

    deployment.endTime = new Date().toISOString();
    deployment.totalDuration = Date.now() - new Date(deployment.startTime).getTime();
    deployment.status = success ? 'success' : 'failed';

    this.deployments.set(deploymentId, deployment);
  }

  getDeploymentProgress(deploymentId: string): DeploymentProgress | undefined {
    return this.deployments.get(deploymentId);
  }

  getAllDeployments(): DeploymentProgress[] {
    return Array.from(this.deployments.values());
  }

  getActiveDeployments(): DeploymentProgress[] {
    return Array.from(this.deployments.values())
      .filter(d => d.status === 'running' || d.status === 'pending');
  }

  getRecentDeployments(limit: number = 10): DeploymentProgress[] {
    return Array.from(this.deployments.values())
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime())
      .slice(0, limit);
  }

  addWarning(deploymentId: string, message: string, details?: string): void {
    this.addStage(deploymentId, 'warning', message, details);
  }

  addRetry(deploymentId: string, operation: string, attempt: number): void {
    this.addStage(
      deploymentId, 
      'retry', 
      `Retrying ${operation} (attempt ${attempt})`,
      `Operation: ${operation}, Attempt: ${attempt}`
    );
  }

  cancelDeployment(deploymentId: string, reason?: string): void {
    const deployment = this.deployments.get(deploymentId);
    if (!deployment) return;

    this.addStage(
      deploymentId, 
      'cancelled', 
      reason || 'Deployment cancelled by user'
    );

    deployment.endTime = new Date().toISOString();
    deployment.totalDuration = Date.now() - new Date(deployment.startTime).getTime();
    
    this.deployments.set(deploymentId, deployment);
  }

  getProgressSummary(deploymentId: string): {
    emoji: string;
    status: string;
    message: string;
    progress: number;
    duration: string;
  } | undefined {
    const deployment = this.deployments.get(deploymentId);
    if (!deployment) return undefined;

    const currentStage = deployment.stages[deployment.stages.length - 1];
    const progressPercent = this.calculateProgress(deployment);
    const duration = this.formatDuration(
      deployment.totalDuration || 
      (Date.now() - new Date(deployment.startTime).getTime())
    );

    return {
      emoji: currentStage?.emoji || '📋',
      status: deployment.status,
      message: currentStage?.message || 'Processing...',
      progress: progressPercent,
      duration
    };
  }

  private calculateProgress(deployment: DeploymentProgress): number {
    const totalStages = this.getTotalStagesForProvider(deployment.provider);
    const completedStages = deployment.stages.filter(s => s.duration).length;
    return Math.min(100, Math.round((completedStages / totalStages) * 100));
  }

  private getTotalStagesForProvider(provider: string): number {
    const stageCounts: Record<string, number> = {
      'azure': 8,
      'replit': 6,
      'aws': 9,
      'gcp': 7
    };
    return stageCounts[provider] || 8;
  }

  private formatDuration(ms: number): string {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (hours > 0) {
      return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    } else {
      return `${seconds}s`;
    }
  }

  // Provider-specific deployment flows
  async runAzureDeployment(
    deploymentId: string,
    spec: {
      name: string;
      image: string;
      resourceGroup: string;
      location: string;
      cpu: number;
      memory: number;
      ports: number[];
      environmentVariables?: Record<string, string>;
    }
  ): Promise<any> {
    this.startDeployment(deploymentId, 'azure', spec);

    try {
      this.addStage(deploymentId, 'validating', 'Validating Azure deployment configuration');
      await this.delay(1000);

      this.addStage(deploymentId, 'authenticating', 'Authenticating with Azure Resource Manager');
      await this.delay(1500);

      this.addStage(deploymentId, 'creating-resource-group', `Creating resource group: ${spec.resourceGroup}`);
      const { azureDirectDeployment } = await import('./azure-direct-deployment');
      await azureDirectDeployment.createResourceGroup(spec.resourceGroup, spec.location);
      await this.delay(2000);

      this.addStage(deploymentId, 'preparing-environment', 'Preparing container environment');
      await this.delay(1000);

      this.addStage(deploymentId, 'deploying-container', `Deploying container: ${spec.name}`);
      const result = await azureDirectDeployment.deployContainer(spec);
      await this.delay(2000);

      this.addStage(deploymentId, 'health-checking', 'Performing health checks');
      await this.delay(1500);

      this.addStage(deploymentId, 'verifying-deployment', 'Verifying deployment status');
      await this.delay(1000);

      this.completeDeployment(deploymentId, true, `Container ${spec.name} deployed successfully`);
      
      return {
        success: true,
        deployment: {
          resourceGroup: spec.resourceGroup,
          containerName: spec.name,
          image: spec.image,
          location: spec.location,
          publicIp: result.properties?.ipAddress?.ip || 'Pending allocation',
          fqdn: result.properties?.ipAddress?.fqdn,
          status: result.properties?.provisioningState || 'Running'
        }
      };

    } catch (error: any) {
      this.addStage(deploymentId, 'error', `Deployment failed: ${error.message}`, error.stack);
      this.completeDeployment(deploymentId, false, error.message);
      return { success: false, error: error.message };
    }
  }

  async runReplitDeployment(
    deploymentId: string,
    spec: {
      name: string;
      template: string;
      description?: string;
      environmentVariables?: Record<string, string>;
    }
  ): Promise<any> {
    this.startDeployment(deploymentId, 'replit', spec);

    try {
      this.addStage(deploymentId, 'validating', 'Validating Replit deployment configuration');
      await this.delay(500);

      this.addStage(deploymentId, 'preparing', 'Preparing Replit project structure');
      await this.delay(1000);

      this.addStage(deploymentId, 'building-image', 'Building application');
      const { replitDeploymentService } = await import('./replit-deployment-service');
      await this.delay(2000);

      this.addStage(deploymentId, 'deploying-container', 'Deploying to Replit infrastructure');
      const result = await replitDeploymentService.createProject(spec);
      await this.delay(1500);

      this.addStage(deploymentId, 'health-checking', 'Checking application health');
      await this.delay(1000);

      this.completeDeployment(deploymentId, true, `Application ${spec.name} deployed successfully`);
      
      return {
        success: true,
        deployment: result
      };

    } catch (error: any) {
      this.addStage(deploymentId, 'error', `Deployment failed: ${error.message}`, error.stack);
      this.completeDeployment(deploymentId, false, error.message);
      return { success: false, error: error.message };
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const deploymentAssistant = new DeploymentAssistant();