import { GoogleAuth } from 'google-auth-library';
import { Storage } from '@google-cloud/storage';
import { PubSub } from '@google-cloud/pubsub';
import { Firestore } from '@google-cloud/firestore';

interface GCPConfig {
  projectId: string;
  keyFilename?: string;
  credentials?: any;
}

interface ComputeInstanceSpec {
  name: string;
  zone: string;
  machineType: string;
  sourceImage: string;
  networkTags?: string[];
  metadata?: Record<string, string>;
  startupScript?: string;
  diskSizeGb?: number;
  preemptible?: boolean;
}

interface StorageBucketSpec {
  name: string;
  location: string;
  storageClass: 'STANDARD' | 'NEARLINE' | 'COLDLINE' | 'ARCHIVE';
  uniformBucketLevelAccess?: boolean;
  versioning?: boolean;
}

export class GCPService {
  private auth: GoogleAuth;
  private storage: Storage;
  private pubsub: PubSub;
  private firestore: Firestore;
  private projectId: string;

  constructor(config: GCPConfig) {
    this.projectId = config.projectId;
    
    const authOptions: any = {
      projectId: config.projectId,
      scopes: [
        'https://www.googleapis.com/auth/cloud-platform',
        'https://www.googleapis.com/auth/compute',
        'https://www.googleapis.com/auth/devstorage.full_control',
        'https://www.googleapis.com/auth/pubsub',
        'https://www.googleapis.com/auth/datastore'
      ]
    };

    if (config.keyFilename) {
      authOptions.keyFilename = config.keyFilename;
    } else if (config.credentials) {
      authOptions.credentials = config.credentials;
    }

    this.auth = new GoogleAuth(authOptions);
    this.storage = new Storage({ projectId: config.projectId });
    this.pubsub = new PubSub({ projectId: config.projectId });
    this.firestore = new Firestore({ projectId: config.projectId });
  }

  // Authentication and Project Management
  async validateAuthentication() {
    try {
      const client = await this.auth.getClient();
      const projectId = await this.auth.getProjectId();
      return {
        authenticated: true,
        projectId,
        clientEmail: (client as any).email || 'authenticated'
      };
    } catch (error: any) {
      throw new Error(`GCP authentication failed: ${error.message}`);
    }
  }

  async getProject() {
    try {
      const client = await this.auth.getClient();
      const url = `https://cloudresourcemanager.googleapis.com/v1/projects/${this.projectId}`;
      const response = await client.request({ url });
      
      return {
        projectId: response.data.projectId,
        projectNumber: response.data.projectNumber,
        name: response.data.name,
        state: response.data.lifecycleState,
        createTime: response.data.createTime
      };
    } catch (error: any) {
      throw new Error(`Failed to get project: ${error.message}`);
    }
  }

  // Compute Engine (using REST API)
  async createComputeInstance(spec: ComputeInstanceSpec) {
    try {
      const client = await this.auth.getClient();
      const url = `https://compute.googleapis.com/compute/v1/projects/${this.projectId}/zones/${spec.zone}/instances`;
      
      const instanceConfig = {
        name: spec.name,
        machineType: `zones/${spec.zone}/machineTypes/${spec.machineType}`,
        disks: [
          {
            boot: true,
            autoDelete: true,
            initializeParams: {
              sourceImage: spec.sourceImage,
              diskSizeGb: spec.diskSizeGb || 10
            }
          }
        ],
        networkInterfaces: [
          {
            network: 'global/networks/default',
            accessConfigs: [
              {
                type: 'ONE_TO_ONE_NAT',
                name: 'External NAT'
              }
            ]
          }
        ],
        tags: {
          items: spec.networkTags || []
        },
        metadata: {
          items: Object.entries(spec.metadata || {}).map(([key, value]) => ({
            key,
            value
          }))
        },
        scheduling: {
          preemptible: spec.preemptible || false
        }
      };

      if (spec.startupScript) {
        instanceConfig.metadata.items.push({
          key: 'startup-script',
          value: spec.startupScript
        });
      }

      const response = await client.request({
        url,
        method: 'POST',
        data: instanceConfig
      });
      
      return {
        id: response.data.id,
        name: spec.name,
        zone: spec.zone,
        machineType: spec.machineType,
        status: 'PROVISIONING',
        selfLink: response.data.selfLink,
        createdAt: new Date().toISOString()
      };
    } catch (error: any) {
      throw new Error(`Failed to create compute instance: ${error.message}`);
    }
  }

  async listComputeInstances(zone?: string) {
    try {
      const client = await this.auth.getClient();
      let url: string;
      
      if (zone) {
        url = `https://compute.googleapis.com/compute/v1/projects/${this.projectId}/zones/${zone}/instances`;
      } else {
        url = `https://compute.googleapis.com/compute/v1/projects/${this.projectId}/aggregated/instances`;
      }
      
      const response = await client.request({ url });
      const instances: any[] = [];
      
      if (zone) {
        instances.push(...(response.data.items || []));
      } else {
        Object.values(response.data.items || {}).forEach((zoneData: any) => {
          if (zoneData.instances) {
            instances.push(...zoneData.instances);
          }
        });
      }
      
      return instances.map(instance => ({
        id: instance.id,
        name: instance.name,
        zone: instance.zone?.split('/').pop(),
        machineType: instance.machineType?.split('/').pop(),
        status: instance.status,
        selfLink: instance.selfLink
      }));
    } catch (error: any) {
      throw new Error(`Failed to list compute instances: ${error.message}`);
    }
  }

  async getComputeInstance(zone: string, instanceName: string) {
    try {
      const client = await this.auth.getClient();
      const url = `https://compute.googleapis.com/compute/v1/projects/${this.projectId}/zones/${zone}/instances/${instanceName}`;
      const response = await client.request({ url });
      
      return {
        id: response.data.id,
        name: response.data.name,
        zone: zone,
        machineType: response.data.machineType?.split('/').pop(),
        status: response.data.status,
        selfLink: response.data.selfLink,
        networkInterfaces: response.data.networkInterfaces,
        disks: response.data.disks,
        metadata: response.data.metadata
      };
    } catch (error: any) {
      throw new Error(`Failed to get compute instance: ${error.message}`);
    }
  }

  async stopComputeInstance(zone: string, instanceName: string) {
    try {
      const client = await this.auth.getClient();
      const url = `https://compute.googleapis.com/compute/v1/projects/${this.projectId}/zones/${zone}/instances/${instanceName}/stop`;
      await client.request({ url, method: 'POST' });
      return { status: 'STOPPING' };
    } catch (error: any) {
      throw new Error(`Failed to stop compute instance: ${error.message}`);
    }
  }

  async startComputeInstance(zone: string, instanceName: string) {
    try {
      const client = await this.auth.getClient();
      const url = `https://compute.googleapis.com/compute/v1/projects/${this.projectId}/zones/${zone}/instances/${instanceName}/start`;
      await client.request({ url, method: 'POST' });
      return { status: 'STARTING' };
    } catch (error: any) {
      throw new Error(`Failed to start compute instance: ${error.message}`);
    }
  }

  async deleteComputeInstance(zone: string, instanceName: string) {
    try {
      const client = await this.auth.getClient();
      const url = `https://compute.googleapis.com/compute/v1/projects/${this.projectId}/zones/${zone}/instances/${instanceName}`;
      await client.request({ url, method: 'DELETE' });
      return { status: 'DELETED' };
    } catch (error: any) {
      throw new Error(`Failed to delete compute instance: ${error.message}`);
    }
  }

  // Cloud Storage
  async createStorageBucket(spec: StorageBucketSpec) {
    try {
      const [bucket] = await this.storage.createBucket(spec.name, {
        location: spec.location,
        storageClass: spec.storageClass,
        uniformBucketLevelAccess: {
          enabled: spec.uniformBucketLevelAccess || false
        },
        versioning: {
          enabled: spec.versioning || false
        }
      });

      return {
        id: bucket.id,
        name: bucket.name,
        location: spec.location,
        storageClass: spec.storageClass,
        selfLink: bucket.metadata.selfLink,
        createdAt: bucket.metadata.timeCreated
      };
    } catch (error: any) {
      throw new Error(`Failed to create storage bucket: ${error.message}`);
    }
  }

  async listStorageBuckets() {
    try {
      const [buckets] = await this.storage.getBuckets();
      return buckets.map(bucket => ({
        id: bucket.id,
        name: bucket.name,
        location: bucket.metadata.location,
        storageClass: bucket.metadata.storageClass,
        selfLink: bucket.metadata.selfLink,
        createdAt: bucket.metadata.timeCreated
      }));
    } catch (error: any) {
      throw new Error(`Failed to list storage buckets: ${error.message}`);
    }
  }

  async deleteStorageBucket(bucketName: string) {
    try {
      await this.storage.bucket(bucketName).delete();
      return { status: 'DELETED' };
    } catch (error: any) {
      throw new Error(`Failed to delete storage bucket: ${error.message}`);
    }
  }

  // Pub/Sub
  async createPubSubTopic(topicName: string) {
    try {
      const [topic] = await this.pubsub.createTopic(topicName);
      return {
        name: topic.name,
        selfLink: `projects/${this.projectId}/topics/${topicName}`,
        createdAt: new Date().toISOString()
      };
    } catch (error: any) {
      throw new Error(`Failed to create Pub/Sub topic: ${error.message}`);
    }
  }

  async listPubSubTopics() {
    try {
      const [topics] = await this.pubsub.getTopics();
      return topics.map(topic => ({
        name: topic.name,
        selfLink: `projects/${this.projectId}/topics/${topic.name.split('/').pop()}`
      }));
    } catch (error: any) {
      throw new Error(`Failed to list Pub/Sub topics: ${error.message}`);
    }
  }

  async createPubSubSubscription(topicName: string, subscriptionName: string) {
    try {
      const topic = this.pubsub.topic(topicName);
      const [subscription] = await topic.createSubscription(subscriptionName);
      return {
        name: subscription.name,
        topic: topicName,
        selfLink: `projects/${this.projectId}/subscriptions/${subscriptionName}`,
        createdAt: new Date().toISOString()
      };
    } catch (error: any) {
      throw new Error(`Failed to create Pub/Sub subscription: ${error.message}`);
    }
  }

  // Firestore
  async createFirestoreDocument(collection: string, documentId: string, data: any) {
    try {
      await this.firestore.collection(collection).doc(documentId).set(data);
      return {
        collection,
        documentId,
        path: `${collection}/${documentId}`,
        createdAt: new Date().toISOString()
      };
    } catch (error: any) {
      throw new Error(`Failed to create Firestore document: ${error.message}`);
    }
  }

  async getFirestoreDocument(collection: string, documentId: string) {
    try {
      const doc = await this.firestore.collection(collection).doc(documentId).get();
      if (!doc.exists) {
        throw new Error('Document not found');
      }
      return {
        collection,
        documentId,
        data: doc.data(),
        path: `${collection}/${documentId}`
      };
    } catch (error: any) {
      throw new Error(`Failed to get Firestore document: ${error.message}`);
    }
  }

  // Resource Management
  async listAllResources() {
    try {
      const [computeInstances, storageBuckets, pubsubTopics] = await Promise.all([
        this.listComputeInstances().catch(() => []),
        this.listStorageBuckets().catch(() => []),
        this.listPubSubTopics().catch(() => [])
      ]);

      return {
        compute: computeInstances,
        storage: storageBuckets,
        pubsub: pubsubTopics,
        summary: {
          totalResources: computeInstances.length + storageBuckets.length + pubsubTopics.length,
          computeInstances: computeInstances.length,
          storageBuckets: storageBuckets.length,
          pubsubTopics: pubsubTopics.length
        }
      };
    } catch (error: any) {
      throw new Error(`Failed to list resources: ${error.message}`);
    }
  }
}

export function getGCPService(): GCPService {
  const projectId = process.env.GCP_PROJECT_ID;
  const serviceAccountKey = process.env.GCP_SERVICE_ACCOUNT_KEY;

  if (!projectId) {
    throw new Error('GCP_PROJECT_ID environment variable is required');
  }

  let credentials;
  if (serviceAccountKey) {
    try {
      credentials = JSON.parse(serviceAccountKey);
    } catch (error) {
      throw new Error('Invalid GCP_SERVICE_ACCOUNT_KEY format');
    }
  }

  return new GCPService({
    projectId,
    credentials
  });
}