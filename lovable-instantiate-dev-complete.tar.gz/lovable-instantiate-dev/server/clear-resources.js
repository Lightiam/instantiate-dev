// Clear all old test resources
const fetch = require('node-fetch');

async function clearResources() {
  try {
    console.log('Clearing old deployments...');
    
    const response = await fetch('http://localhost:5000/api/cleanup/all', {
      method: 'DELETE'
    });
    
    const result = await response.json();
    console.log('Cleanup result:', result);
    
    // Also clear multi-cloud resources if possible
    const resourcesResponse = await fetch('http://localhost:5000/api/multi-cloud/resources');
    const resources = await resourcesResponse.json();
    
    console.log(`Found ${resources.length} resources to clean`);
    
    // Force refresh
    const healthResponse = await fetch('http://localhost:5000/api/multi-cloud/health');
    const health = await healthResponse.json();
    
    console.log('Health check:', health);
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

clearResources();