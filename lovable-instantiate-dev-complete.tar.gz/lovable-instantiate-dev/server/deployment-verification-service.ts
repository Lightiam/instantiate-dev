import express from 'express';
import fetch from 'node-fetch';

interface DeploymentVerification {
  deploymentId: string;
  provider: 'replit' | 'azure' | 'netlify';
  url: string;
  status: 'accessible' | 'failed' | 'pending';
  responseTime?: number;
  httpStatus?: number;
  lastChecked: string;
  metadata?: any;
}

export class DeploymentVerificationService {
  private verifications = new Map<string, DeploymentVerification>();

  async verifyDeployment(deploymentId: string, provider: 'replit' | 'azure' | 'netlify', url: string): Promise<DeploymentVerification> {
    const startTime = Date.now();
    
    try {
      const response = await fetch(url, {
        method: 'GET',
        timeout: 10000,
        redirect: 'follow'
      });

      const responseTime = Date.now() - startTime;
      const verification: DeploymentVerification = {
        deploymentId,
        provider,
        url,
        status: response.ok ? 'accessible' : 'failed',
        responseTime,
        httpStatus: response.status,
        lastChecked: new Date().toISOString(),
        metadata: {
          contentType: response.headers.get('content-type'),
          contentLength: response.headers.get('content-length'),
          server: response.headers.get('server')
        }
      };

      this.verifications.set(deploymentId, verification);
      return verification;

    } catch (error: any) {
      const verification: DeploymentVerification = {
        deploymentId,
        provider,
        url,
        status: 'failed',
        responseTime: Date.now() - startTime,
        lastChecked: new Date().toISOString(),
        metadata: {
          error: error.message
        }
      };

      this.verifications.set(deploymentId, verification);
      return verification;
    }
  }

  async verifyMultipleDeployments(deployments: Array<{id: string, provider: 'replit' | 'azure' | 'netlify', url: string}>): Promise<DeploymentVerification[]> {
    const verificationPromises = deployments.map(deployment => 
      this.verifyDeployment(deployment.id, deployment.provider, deployment.url)
    );

    return Promise.all(verificationPromises);
  }

  getVerification(deploymentId: string): DeploymentVerification | undefined {
    return this.verifications.get(deploymentId);
  }

  getAllVerifications(): DeploymentVerification[] {
    return Array.from(this.verifications.values()).sort((a, b) => 
      new Date(b.lastChecked).getTime() - new Date(a.lastChecked).getTime()
    );
  }

  getSuccessfulDeployments(): DeploymentVerification[] {
    return this.getAllVerifications().filter(v => v.status === 'accessible');
  }

  getDeploymentStats(): {
    total: number;
    accessible: number;
    failed: number;
    successRate: number;
    averageResponseTime: number;
  } {
    const verifications = this.getAllVerifications();
    const accessible = verifications.filter(v => v.status === 'accessible');
    const failed = verifications.filter(v => v.status === 'failed');
    
    const totalResponseTime = accessible.reduce((sum, v) => sum + (v.responseTime || 0), 0);
    const averageResponseTime = accessible.length > 0 ? totalResponseTime / accessible.length : 0;

    return {
      total: verifications.length,
      accessible: accessible.length,
      failed: failed.length,
      successRate: verifications.length > 0 ? (accessible.length / verifications.length) * 100 : 0,
      averageResponseTime: Math.round(averageResponseTime)
    };
  }

  generateStatusReport(): string {
    const stats = this.getDeploymentStats();
    const successful = this.getSuccessfulDeployments();

    return `
# Deployment Verification Report

## Summary
- Total Deployments: ${stats.total}
- Successful: ${stats.accessible}
- Failed: ${stats.failed}
- Success Rate: ${stats.successRate.toFixed(1)}%
- Average Response Time: ${stats.averageResponseTime}ms

## Live Applications
${successful.map(deployment => `
### ${deployment.deploymentId}
- Provider: ${deployment.provider}
- URL: ${deployment.url}
- Status: ${deployment.httpStatus}
- Response Time: ${deployment.responseTime}ms
- Last Verified: ${new Date(deployment.lastChecked).toLocaleString()}
`).join('')}

Generated at: ${new Date().toLocaleString()}
    `.trim();
  }
}

export const deploymentVerificationService = new DeploymentVerificationService();