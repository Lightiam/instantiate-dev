import { URLSearchParams } from 'url';
import fetch from 'node-fetch';

interface AzureWebAppRequest {
  name: string;
  code: string;
  codeType: 'javascript' | 'python' | 'html';
  resourceGroup: string;
  location: string;
  environmentVariables?: Record<string, string>;
}

export class AzureWebAppDeployment {
  private credentials = {
    clientId: "abb8ccdc-a48e-4b14-979e-161f4f3072f0",
    clientSecret: "Yam8Q~0ZhFR7r3ALz2DBOFr2qMkHePj4HzwJ1crn",
    tenantId: "4d2858d9-441d-46f0-b085-60e4ca7a5e75",
    subscriptionId: "3e513234-2b8a-4b15-8632-203397fae29f"
  };

  private async getAccessToken(): Promise<string> {
    const tokenUrl = `https://login.microsoftonline.com/${this.credentials.tenantId}/oauth2/v2.0/token`;
    
    const params = new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: this.credentials.clientId,
      client_secret: this.credentials.clientSecret,
      scope: 'https://management.azure.com/.default'
    });

    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });

    const data: any = await response.json();
    if (!response.ok) {
      throw new Error(`Authentication failed: ${JSON.stringify(data)}`);
    }

    return data.access_token;
  }

  private async makeAzureRequest(path: string, method: string = 'GET', body: any = null, apiVersion: string = '2022-03-01'): Promise<any> {
    const token = await this.getAccessToken();
    const url = `https://management.azure.com${path}?api-version=${apiVersion}`;
    
    const headers: Record<string, string> = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    const options: any = {
      method,
      headers,
      ...(body && { body: JSON.stringify(body) })
    };

    const response = await fetch(url, options as any);
    const responseData = await response.text();
    
    if (!response.ok) {
      throw new Error(`Azure API error: ${response.status} - ${responseData}`);
    }

    return responseData ? JSON.parse(responseData) : {};
  }

  async deployWebApp(spec: AzureWebAppRequest): Promise<any> {
    // 1. Ensure resource group exists
    await this.ensureResourceGroup(spec.resourceGroup, spec.location);

    // 2. Create App Service Plan
    const planName = `${spec.name}-plan`;
    await this.createAppServicePlan(spec.resourceGroup, planName, spec.location);

    // 3. Create Web App
    const webApp = await this.createWebApp(spec.resourceGroup, spec.name, planName, spec.location);

    // 4. Deploy code using ZIP deployment
    await this.deployCode(spec.resourceGroup, spec.name, spec.code, spec.codeType);

    // 5. Set environment variables
    if (spec.environmentVariables) {
      await this.setEnvironmentVariables(spec.resourceGroup, spec.name, spec.environmentVariables);
    }

    return {
      name: spec.name,
      resourceGroup: spec.resourceGroup,
      url: `https://${spec.name}.azurewebsites.net`,
      status: 'Deployed',
      provider: 'azure-webapp',
      codeDeployed: true
    };
  }

  private async ensureResourceGroup(resourceGroup: string, location: string): Promise<void> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}`;
    
    try {
      await this.makeAzureRequest(path);
    } catch (error) {
      // Create resource group if it doesn't exist
      const body = {
        location: location,
        tags: {
          createdBy: 'Instanti8-Platform',
          purpose: 'webapp-deployment'
        }
      };
      
      await this.makeAzureRequest(path, 'PUT', body);
    }
  }

  private async createAppServicePlan(resourceGroup: string, planName: string, location: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Web/serverfarms/${planName}`;
    
    try {
      return await this.makeAzureRequest(path);
    } catch (error) {
      // Create new plan
      const body = {
        location: location,
        sku: {
          name: 'F1', // Free tier
          tier: 'Free',
          size: 'F1',
          family: 'F',
          capacity: 1
        },
        properties: {
          reserved: false // Windows App Service Plan
        }
      };
      
      return await this.makeAzureRequest(path, 'PUT', body);
    }
  }

  private async createWebApp(resourceGroup: string, siteName: string, planName: string, location: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Web/sites/${siteName}`;
    
    const body = {
      location: location,
      properties: {
        serverFarmId: `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Web/serverfarms/${planName}`,
        siteConfig: {
          appSettings: [
            {
              name: 'WEBSITE_NODE_DEFAULT_VERSION',
              value: '18.x'
            }
          ]
        }
      }
    };
    
    return await this.makeAzureRequest(path, 'PUT', body);
  }

  private async deployCode(resourceGroup: string, siteName: string, code: string, codeType: string): Promise<void> {
    // Create deployable package based on code type
    let deploymentContent: any;
    
    if (codeType === 'javascript') {
      // Create a simple Node.js app
      deploymentContent = {
        'package.json': JSON.stringify({
          name: siteName,
          version: '1.0.0',
          main: 'server.js',
          scripts: {
            start: 'node server.js'
          },
          dependencies: {
            express: '^4.18.0'
          }
        }, null, 2),
        'server.js': code.includes('express') ? code : `
const http = require('http');
const port = process.env.PORT || 8080;

${code}

// Fallback server if user code doesn't create one
if (!global.serverCreated) {
  const server = http.createServer((req, res) => {
    res.writeHead(200, {'Content-Type': 'application/json'});
    res.end(JSON.stringify({
      message: 'User code deployed to Azure Web App',
      timestamp: new Date().toISOString(),
      userCode: \`${code.substring(0, 100)}...\`
    }));
  });
  
  server.listen(port, () => {
    console.log(\`Server running on port \${port}\`);
  });
}
        `.trim()
      };
    } else if (codeType === 'html') {
      deploymentContent = {
        'index.html': code,
        'web.config': `<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <system.webServer>
    <defaultDocument>
      <files>
        <clear />
        <add value="index.html" />
      </files>
    </defaultDocument>
  </system.webServer>
</configuration>`
      };
    } else {
      // Generic deployment
      deploymentContent = {
        'server.js': `
const http = require('http');
const port = process.env.PORT || 8080;

const server = http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end(\`User Code: ${code}\`);
});

server.listen(port, () => {
  console.log(\`Server running on port \${port}\`);
});
        `.trim(),
        'package.json': JSON.stringify({
          name: siteName,
          version: '1.0.0',
          main: 'server.js',
          scripts: { start: 'node server.js' }
        })
      };
    }

    // Deploy using SCM API (Kudu)
    await this.deployViaKudu(resourceGroup, siteName, deploymentContent);
  }

  private async deployViaKudu(resourceGroup: string, siteName: string, files: Record<string, string>): Promise<void> {
    // Get publishing credentials
    const credsPath = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Web/sites/${siteName}/config/publishingcredentials/list`;
    const creds = await this.makeAzureRequest(credsPath, 'POST');
    
    const username = creds.properties.publishingUserName;
    const password = creds.properties.publishingPassword;
    
    // Deploy files via Kudu VFS API
    for (const [filename, content] of Object.entries(files)) {
      const kuduUrl = `https://${siteName}.scm.azurewebsites.net/api/vfs/site/wwwroot/${filename}`;
      
      const response = await fetch(kuduUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`,
          'Content-Type': 'text/plain'
        },
        body: content
      });
      
      if (!response.ok) {
        throw new Error(`Failed to deploy ${filename}: ${response.statusText}`);
      }
    }
  }

  private async setEnvironmentVariables(resourceGroup: string, siteName: string, envVars: Record<string, string>): Promise<void> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Web/sites/${siteName}/config/appsettings`;
    
    // Get current settings
    const currentSettings = await this.makeAzureRequest(path);
    
    // Merge with new variables
    const updatedSettings = {
      properties: {
        ...currentSettings.properties,
        ...envVars
      }
    };
    
    await this.makeAzureRequest(path, 'PUT', updatedSettings);
  }

  async getWebAppStatus(resourceGroup: string, siteName: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Web/sites/${siteName}`;
    return await this.makeAzureRequest(path);
  }

  async listWebApps(resourceGroup?: string): Promise<any[]> {
    let path: string;
    
    if (resourceGroup) {
      path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Web/sites`;
    } else {
      path = `/subscriptions/${this.credentials.subscriptionId}/providers/Microsoft.Web/sites`;
    }
    
    const result = await this.makeAzureRequest(path);
    return result.value || [];
  }
}

export const azureWebAppDeployment = new AzureWebAppDeployment();