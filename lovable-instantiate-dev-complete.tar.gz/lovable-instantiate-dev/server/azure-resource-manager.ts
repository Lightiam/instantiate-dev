import { ResourceManagementClient } from '@azure/arm-resources';
import { ClientSecretCredential } from '@azure/identity';

interface ARMTemplate {
  $schema: string;
  contentVersion: string;
  parameters: Record<string, any>;
  variables: Record<string, any>;
  resources: ARMResource[];
  outputs: Record<string, any>;
}

interface ARMResource {
  type: string;
  apiVersion: string;
  name: string;
  location?: string;
  properties: Record<string, any>;
  dependsOn?: string[];
  tags?: Record<string, string>;
  sku?: Record<string, any>;
  kind?: string;
}

interface ARMDeployment {
  deploymentId: string;
  resourceGroupName: string;
  deploymentName: string;
  template: ARMTemplate;
  parameters: Record<string, any>;
  status: 'pending' | 'running' | 'succeeded' | 'failed' | 'cancelled';
  outputs?: Record<string, any>;
  error?: string;
  resources: ARMDeployedResource[];
  createdAt: string;
  updatedAt: string;
}

interface ARMDeployedResource {
  id: string;
  name: string;
  type: string;
  location: string;
  status: string;
  properties: Record<string, any>;
}

export class AzureResourceManager {
  private client: ResourceManagementClient;
  private subscriptionId: string;
  private deployments = new Map<string, ARMDeployment>();

  constructor() {
    const clientId = process.env.AZURE_CLIENT_ID;
    const clientSecret = process.env.AZURE_CLIENT_SECRET;
    const tenantId = process.env.AZURE_TENANT_ID;
    this.subscriptionId = process.env.AZURE_SUBSCRIPTION_ID!;

    if (!clientId || !clientSecret || !tenantId || !this.subscriptionId) {
      throw new Error('Azure credentials not configured');
    }

    const credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
    this.client = new ResourceManagementClient(credential, this.subscriptionId);
  }

  async createResourceGroup(name: string, location: string): Promise<any> {
    const resourceGroup = {
      location,
      tags: {
        'created-by': 'instanti8-arm',
        'created-at': new Date().toISOString()
      }
    };

    return await this.client.resourceGroups.createOrUpdate(name, resourceGroup);
  }

  async deployTemplate(
    resourceGroupName: string,
    deploymentName: string,
    template: ARMTemplate,
    parameters: Record<string, any> = {}
  ): Promise<ARMDeployment> {
    const deploymentId = `arm-${Date.now()}`;
    
    const deployment: ARMDeployment = {
      deploymentId,
      resourceGroupName,
      deploymentName,
      template,
      parameters,
      status: 'pending',
      resources: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.deployments.set(deploymentId, deployment);

    try {
      // Ensure resource group exists
      await this.createResourceGroup(resourceGroupName, template.variables?.location || 'East US');

      deployment.status = 'running';
      deployment.updatedAt = new Date().toISOString();
      this.deployments.set(deploymentId, deployment);

      // Deploy ARM template
      const deploymentParameters = {
        properties: {
          template: template as any,
          parameters: this.formatParameters(parameters),
          mode: 'Incremental' as any
        }
      };

      const result = await this.client.deployments.beginCreateOrUpdateAndWait(
        resourceGroupName,
        deploymentName,
        deploymentParameters
      );

      // Get deployment outputs
      const outputs = result.properties?.outputs || {};
      
      // List deployed resources
      const resources = await this.getDeployedResources(resourceGroupName, deploymentName);

      deployment.status = result.properties?.provisioningState?.toLowerCase() as any || 'succeeded';
      deployment.outputs = outputs;
      deployment.resources = resources;
      deployment.updatedAt = new Date().toISOString();
      this.deployments.set(deploymentId, deployment);

      return deployment;
    } catch (error: any) {
      deployment.status = 'failed';
      deployment.error = error.message;
      deployment.updatedAt = new Date().toISOString();
      this.deployments.set(deploymentId, deployment);
      throw error;
    }
  }

  async getDeployedResources(resourceGroupName: string, deploymentName: string): Promise<ARMDeployedResource[]> {
    try {
      const deployment = await this.client.deployments.get(resourceGroupName, deploymentName);
      const operations = await this.client.deploymentOperations.list(resourceGroupName, deploymentName);
      
      const resources: ARMDeployedResource[] = [];
      
      for await (const operation of operations) {
        if (operation.properties?.targetResource) {
          const resource = operation.properties.targetResource;
          resources.push({
            id: resource.id || '',
            name: resource.resourceName || '',
            type: resource.resourceType || '',
            location: (deployment.properties?.outputs as any)?.location?.value || '',
            status: operation.properties?.provisioningState || 'unknown',
            properties: (operation.properties as any)?.responseContent || {}
          });
        }
      }

      return resources;
    } catch (error) {
      console.error('Error getting deployed resources:', error);
      return [];
    }
  }

  private formatParameters(parameters: Record<string, any>): Record<string, any> {
    const formattedParams: Record<string, any> = {};
    
    for (const [key, value] of Object.entries(parameters)) {
      formattedParams[key] = {
        value: value
      };
    }
    
    return formattedParams;
  }

  async generateContainerTemplate(spec: {
    containerName: string;
    image: string;
    cpu: number;
    memory: number;
    ports: number[];
    location: string;
    environmentVariables?: Record<string, string>;
  }): Promise<ARMTemplate> {
    return {
      $schema: "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
      contentVersion: "1.0.0.0",
      parameters: {
        containerName: {
          type: "string",
          defaultValue: spec.containerName
        },
        image: {
          type: "string",
          defaultValue: spec.image
        },
        location: {
          type: "string",
          defaultValue: spec.location
        }
      },
      variables: {
        location: spec.location
      },
      resources: [
        {
          type: "Microsoft.ContainerInstance/containerGroups",
          apiVersion: "2021-09-01",
          name: "[parameters('containerName')]",
          location: "[parameters('location')]",
          properties: {
            containers: [
              {
                name: spec.containerName,
                properties: {
                  image: "[parameters('image')]",
                  resources: {
                    requests: {
                      cpu: spec.cpu,
                      memoryInGb: spec.memory
                    }
                  },
                  ports: spec.ports.map(port => ({ port })),
                  environmentVariables: Object.entries(spec.environmentVariables || {}).map(([name, value]) => ({
                    name,
                    value
                  }))
                }
              }
            ],
            osType: "Linux",
            ipAddress: {
              type: "Public",
              ports: spec.ports.map(port => ({
                protocol: "TCP",
                port
              }))
            }
          },
          tags: {
            'created-by': 'instanti8-arm',
            'resource-type': 'container',
            'created-at': new Date().toISOString()
          }
        }
      ],
      outputs: {
        containerIPAddress: {
          type: "string",
          value: "[reference(resourceId('Microsoft.ContainerInstance/containerGroups', parameters('containerName'))).ipAddress.ip]"
        },
        containerFQDN: {
          type: "string",
          value: "[reference(resourceId('Microsoft.ContainerInstance/containerGroups', parameters('containerName'))).ipAddress.fqdn]"
        }
      }
    };
  }

  async generateWebAppTemplate(spec: {
    appName: string;
    location: string;
    sku: string;
    runtime: string;
    environmentVariables?: Record<string, string>;
  }): Promise<ARMTemplate> {
    return {
      $schema: "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
      contentVersion: "1.0.0.0",
      parameters: {
        appName: {
          type: "string",
          defaultValue: spec.appName
        },
        location: {
          type: "string",
          defaultValue: spec.location
        },
        sku: {
          type: "string",
          defaultValue: spec.sku
        }
      },
      variables: {
        appServicePlanName: "[concat(parameters('appName'), '-plan')]"
      },
      resources: [
        {
          type: "Microsoft.Web/serverfarms",
          apiVersion: "2021-02-01",
          name: "[variables('appServicePlanName')]",
          location: "[parameters('location')]",
          properties: {
            reserved: true
          },
          sku: {
            name: "[parameters('sku')]"
          },
          kind: "linux"
        },
        {
          type: "Microsoft.Web/sites",
          apiVersion: "2021-02-01",
          name: "[parameters('appName')]",
          location: "[parameters('location')]",
          dependsOn: [
            "[resourceId('Microsoft.Web/serverfarms', variables('appServicePlanName'))]"
          ],
          properties: {
            serverFarmId: "[resourceId('Microsoft.Web/serverfarms', variables('appServicePlanName'))]",
            siteConfig: {
              linuxFxVersion: spec.runtime,
              appSettings: Object.entries(spec.environmentVariables || {}).map(([name, value]) => ({
                name,
                value
              }))
            }
          },
          tags: {
            'created-by': 'instanti8-arm',
            'resource-type': 'webapp',
            'created-at': new Date().toISOString()
          }
        }
      ],
      outputs: {
        webAppUrl: {
          type: "string",
          value: "[concat('https://', reference(resourceId('Microsoft.Web/sites', parameters('appName'))).defaultHostName)]"
        }
      }
    };
  }

  async generateDatabaseTemplate(spec: {
    serverName: string;
    databaseName: string;
    location: string;
    adminUsername: string;
    adminPassword: string;
    sku: string;
  }): Promise<ARMTemplate> {
    return {
      $schema: "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
      contentVersion: "1.0.0.0",
      parameters: {
        serverName: {
          type: "string",
          defaultValue: spec.serverName
        },
        databaseName: {
          type: "string",
          defaultValue: spec.databaseName
        },
        location: {
          type: "string",
          defaultValue: spec.location
        },
        adminUsername: {
          type: "string",
          defaultValue: spec.adminUsername
        },
        adminPassword: {
          type: "securestring"
        }
      },
      variables: {},
      resources: [
        {
          type: "Microsoft.Sql/servers",
          apiVersion: "2021-11-01",
          name: "[parameters('serverName')]",
          location: "[parameters('location')]",
          properties: {
            administratorLogin: "[parameters('adminUsername')]",
            administratorLoginPassword: "[parameters('adminPassword')]",
            version: "12.0"
          },
          tags: {
            'created-by': 'instanti8-arm',
            'resource-type': 'sql-server',
            'created-at': new Date().toISOString()
          }
        },
        {
          type: "Microsoft.Sql/servers/databases",
          apiVersion: "2021-11-01",
          name: "[concat(parameters('serverName'), '/', parameters('databaseName'))]",
          location: "[parameters('location')]",
          dependsOn: [
            "[resourceId('Microsoft.Sql/servers', parameters('serverName'))]"
          ],
          properties: {},
          sku: {
            name: spec.sku
          },
          tags: {
            'created-by': 'instanti8-arm',
            'resource-type': 'sql-database',
            'created-at': new Date().toISOString()
          }
        },
        {
          type: "Microsoft.Sql/servers/firewallRules",
          apiVersion: "2021-11-01",
          name: "[concat(parameters('serverName'), '/AllowAzureIps')]",
          location: "[parameters('location')]",
          dependsOn: [
            "[resourceId('Microsoft.Sql/servers', parameters('serverName'))]"
          ],
          properties: {
            startIpAddress: "0.0.0.0",
            endIpAddress: "0.0.0.0"
          }
        }
      ],
      outputs: {
        serverFQDN: {
          type: "string",
          value: "[reference(resourceId('Microsoft.Sql/servers', parameters('serverName'))).fullyQualifiedDomainName]"
        },
        connectionString: {
          type: "string",
          value: "[concat('Server=tcp:', reference(resourceId('Microsoft.Sql/servers', parameters('serverName'))).fullyQualifiedDomainName, ',1433;Initial Catalog=', parameters('databaseName'), ';Persist Security Info=False;User ID=', parameters('adminUsername'), ';Password=', parameters('adminPassword'), ';MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;')]"
        }
      }
    };
  }

  async listResourceGroups(): Promise<any[]> {
    const resourceGroups = [];
    for await (const rg of this.client.resourceGroups.list()) {
      resourceGroups.push(rg);
    }
    return resourceGroups;
  }

  async getDeployment(deploymentId: string): Promise<ARMDeployment | undefined> {
    return this.deployments.get(deploymentId);
  }

  async getAllDeployments(): Promise<ARMDeployment[]> {
    return Array.from(this.deployments.values());
  }

  async deleteDeployment(resourceGroupName: string, deploymentName: string): Promise<void> {
    await this.client.deployments.beginDeleteAndWait(resourceGroupName, deploymentName);
  }

  async getDeploymentLogs(resourceGroupName: string, deploymentName: string): Promise<any[]> {
    const operations = [];
    for await (const operation of this.client.deploymentOperations.list(resourceGroupName, deploymentName)) {
      operations.push(operation);
    }
    return operations;
  }
}

export const azureResourceManager = new AzureResourceManager();