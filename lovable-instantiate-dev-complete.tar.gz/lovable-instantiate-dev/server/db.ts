import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

// Default database URL for immediate deployment
const defaultDatabaseUrl = "postgresql://neondb_owner:npg_FE5lzguCWNQ7@ep-plain-cake-a5dj6iy2.us-east-2.aws.neon.tech/neondb?sslmode=require";

const databaseUrl = process.env.DATABASE_URL || defaultDatabaseUrl;

export const pool = new Pool({ connectionString: databaseUrl });
export const db = drizzle({ client: pool, schema });