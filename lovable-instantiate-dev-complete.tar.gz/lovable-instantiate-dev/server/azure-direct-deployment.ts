import https from 'https';
import fetch from 'node-fetch';
import { URLSearchParams } from 'url';

interface AzureCredentials {
  clientId: string;
  clientSecret: string;
  tenantId: string;
  subscriptionId: string;
}

interface ContainerDeploymentSpec {
  name: string;
  image: string;
  resourceGroup: string;
  location: string;
  cpu: number;
  memory: number;
  ports: number[];
  environmentVariables?: Record<string, string>;
}

export class AzureDirectDeployment {
  private credentials: AzureCredentials;

  constructor() {
    this.credentials = {
      clientId: process.env.AZURE_CLIENT_ID || "abb8ccdc-a48e-4b14-979e-161f4f3072f0",
      clientSecret: process.env.AZURE_CLIENT_SECRET || "Yam8Q~0ZhFR7r3ALz2DBOFr2qMkHePj4HzwJ1crn",
      tenantId: process.env.AZURE_TENANT_ID || "4d2858d9-441d-46f0-b085-60e4ca7a5e75",
      subscriptionId: process.env.AZURE_SUBSCRIPTION_ID || "3e513234-2b8a-4b15-8632-203397fae29f"
    };
  }

  private async getAccessToken(): Promise<string> {
    const tokenUrl = `https://login.microsoftonline.com/${this.credentials.tenantId}/oauth2/v2.0/token`;
    const params = new URLSearchParams({
      client_id: this.credentials.clientId,
      client_secret: this.credentials.clientSecret,
      scope: 'https://management.azure.com/.default',
      grant_type: 'client_credentials'
    });

    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });

    if (!response.ok) {
      throw new Error(`Token acquisition failed: ${response.status}`);
    }

    const data: any = await response.json();
    return data.access_token;
  }

  async createResourceGroup(name: string, location: string): Promise<any> {
    const accessToken = await this.getAccessToken();
    const url = `https://management.azure.com/subscriptions/${this.credentials.subscriptionId}/resourcegroups/${name}?api-version=2021-04-01`;

    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        location: location,
        tags: {
          'created-by': 'instanti8-platform',
          'created-at': new Date().toISOString()
        }
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Resource group creation failed: ${response.status} - ${error}`);
    }

    return response.json();
  }

  async deployContainer(spec: ContainerDeploymentSpec): Promise<any> {
    const accessToken = await this.getAccessToken();
    
    // First ensure resource group exists
    await this.createResourceGroup(spec.resourceGroup, spec.location);

    const url = `https://management.azure.com/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${spec.resourceGroup}/providers/Microsoft.ContainerInstance/containerGroups/${spec.name}?api-version=2023-05-01`;

    const envVars = Object.entries(spec.environmentVariables || {}).map(([name, value]) => ({
      name,
      value
    }));

    const containerDefinition = {
      location: spec.location,
      properties: {
        containers: [{
          name: spec.name,
          properties: {
            image: spec.image,
            resources: {
              requests: {
                cpu: spec.cpu,
                memoryInGb: spec.memory
              }
            },
            ports: spec.ports.map(port => ({ port })),
            environmentVariables: envVars
          }
        }],
        osType: 'Linux',
        ipAddress: {
          type: 'Public',
          ports: spec.ports.map(port => ({ protocol: 'TCP', port }))
        }
      },
      tags: {
        'created-by': 'instanti8-platform',
        'deployment-type': 'container',
        'image': spec.image,
        'created-at': new Date().toISOString()
      }
    };

    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(containerDefinition)
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Container deployment failed: ${response.status} - ${error}`);
    }

    return response.json();
  }

  async getContainerStatus(resourceGroup: string, containerName: string): Promise<any> {
    const accessToken = await this.getAccessToken();
    const url = `https://management.azure.com/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.ContainerInstance/containerGroups/${containerName}?api-version=2023-05-01`;

    const response = await fetch(url, {
      headers: { 'Authorization': `Bearer ${accessToken}` }
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Container status check failed: ${response.status} - ${error}`);
    }

    return response.json();
  }

  async deleteResourceGroup(resourceGroup: string): Promise<boolean> {
    const accessToken = await this.getAccessToken();
    const url = `https://management.azure.com/subscriptions/${this.credentials.subscriptionId}/resourcegroups/${resourceGroup}?api-version=2021-04-01`;

    const response = await fetch(url, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${accessToken}` }
    });

    return response.ok || response.status === 204;
  }

  async listResourceGroups(): Promise<any[]> {
    const accessToken = await this.getAccessToken();
    const url = `https://management.azure.com/subscriptions/${this.credentials.subscriptionId}/resourcegroups?api-version=2021-04-01`;

    const response = await fetch(url, {
      headers: { 'Authorization': `Bearer ${accessToken}` }
    });

    if (!response.ok) {
      throw new Error(`Failed to list resource groups: ${response.status}`);
    }

    const data: any = await response.json();
    return data.value || [];
  }

  async testFullDeployment(): Promise<any> {
    const timestamp = Date.now();
    const spec: ContainerDeploymentSpec = {
      name: 'instanti8-test-app',
      image: 'nginx:latest',
      resourceGroup: `instanti8-test-${timestamp}`,
      location: 'eastus',
      cpu: 1,
      memory: 1.5,
      ports: [80],
      environmentVariables: {
        'DEPLOYED_BY': 'Instanti8-Platform',
        'DEPLOYMENT_TIME': new Date().toISOString(),
        'TEST_ID': timestamp.toString()
      }
    };

    try {
      console.log('Starting Azure direct deployment test...');
      
      // Deploy container
      const deployment = await this.deployContainer(spec);
      console.log('Container deployment initiated');

      // Wait for deployment to complete
      let retries = 0;
      let containerStatus;
      
      do {
        await new Promise(resolve => setTimeout(resolve, 10000)); // Wait 10 seconds
        containerStatus = await this.getContainerStatus(spec.resourceGroup, spec.name);
        retries++;
      } while (containerStatus.properties.provisioningState === 'Pending' && retries < 12); // Max 2 minutes

      const result = {
        success: true,
        deployment: {
          resourceGroup: spec.resourceGroup,
          containerName: spec.name,
          image: spec.image,
          location: spec.location,
          publicIp: containerStatus.properties.ipAddress?.ip,
          fqdn: containerStatus.properties.ipAddress?.fqdn,
          provisioningState: containerStatus.properties.provisioningState,
          createdAt: new Date().toISOString()
        }
      };

      // Schedule cleanup after 5 minutes
      setTimeout(async () => {
        try {
          await this.deleteResourceGroup(spec.resourceGroup);
          console.log(`Cleanup completed for ${spec.resourceGroup}`);
        } catch (error) {
          console.error(`Cleanup failed:`, error);
        }
      }, 300000);

      return result;

    } catch (error: any) {
      return {
        success: false,
        error: error.message,
        resourceGroup: spec.resourceGroup
      };
    }
  }
}

export const azureDirectDeployment = new AzureDirectDeployment();