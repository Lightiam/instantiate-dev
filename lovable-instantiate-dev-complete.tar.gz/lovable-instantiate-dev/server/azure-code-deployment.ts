import { ClientSecretCredential } from '@azure/identity';
import { ContainerRegistryManagementClient } from '@azure/arm-containerregistry';
import { writeFileSync, mkdirSync, existsSync } from 'fs';
import { execSync } from 'child_process';
import path from 'path';

interface CodeDeploymentSpec {
  name: string;
  code: string;
  codeType: 'javascript' | 'python' | 'html';
  resourceGroup: string;
  location: string;
  ports: number[];
  environmentVariables?: Record<string, string>;
}

interface AzureCredentials {
  clientId: string;
  clientSecret: string;
  tenantId: string;
  subscriptionId: string;
}

export class AzureCodeDeployment {
  private credentials: AzureCredentials;
  private registryClient: ContainerRegistryManagementClient;
  private registryName: string;

  constructor() {
    this.credentials = {
      clientId: process.env.AZURE_CLIENT_ID!,
      clientSecret: process.env.AZURE_CLIENT_SECRET!,
      tenantId: process.env.AZURE_TENANT_ID!,
      subscriptionId: process.env.AZURE_SUBSCRIPTION_ID!
    };

    const credential = new ClientSecretCredential(
      this.credentials.tenantId,
      this.credentials.clientId,
      this.credentials.clientSecret
    );

    this.registryClient = new ContainerRegistryManagementClient(
      credential,
      this.credentials.subscriptionId
    );

    this.registryName = 'instanti8registry';
  }

  async deployCode(spec: CodeDeploymentSpec): Promise<any> {
    // Direct code injection approach - more reliable than Docker builds
    return await this.deployWithCodeInjection(spec);
  }

  private createDeploymentFiles(deployDir: string, spec: CodeDeploymentSpec): void {
    if (!existsSync(deployDir)) {
      mkdirSync(deployDir, { recursive: true });
    }

    // Create Dockerfile
    const dockerfile = this.generateDockerfile(spec);
    writeFileSync(path.join(deployDir, 'Dockerfile'), dockerfile);

    // Create application files
    if (spec.codeType === 'javascript') {
      writeFileSync(path.join(deployDir, 'app.js'), spec.code);
      writeFileSync(path.join(deployDir, 'package.json'), JSON.stringify({
        name: spec.name,
        version: '1.0.0',
        main: 'app.js',
        scripts: {
          start: 'node app.js'
        },
        dependencies: {
          express: '^4.18.0'
        }
      }, null, 2));
    } else if (spec.codeType === 'html') {
      writeFileSync(path.join(deployDir, 'index.html'), spec.code);
    }
  }

  private generateDockerfile(spec: CodeDeploymentSpec): string {
    if (spec.codeType === 'javascript') {
      return `
FROM node:18-alpine
WORKDIR /app
COPY package.json .
RUN npm install
COPY app.js .
EXPOSE ${spec.ports[0] || 3000}
CMD ["npm", "start"]
`.trim();
    } else if (spec.codeType === 'html') {
      return `
FROM nginx:alpine
COPY index.html /usr/share/nginx/html/
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
`.trim();
    }
    
    return `
FROM alpine:latest
RUN echo '${spec.code}' > /app.txt
EXPOSE ${spec.ports[0] || 80}
CMD ["cat", "/app.txt"]
`.trim();
  }

  private async ensureContainerRegistry(resourceGroup: string, location: string): Promise<void> {
    try {
      await this.registryClient.registries.get(resourceGroup, this.registryName);
    } catch (error) {
      // Create registry if it doesn't exist
      await this.registryClient.registries.beginCreateAndWait(resourceGroup, this.registryName, {
        location: location,
        sku: { name: 'Basic' },
        adminUserEnabled: true
      });
    }
  }

  private async deployContainerInstance(spec: CodeDeploymentSpec, imageName: string): Promise<any> {
    // Use existing Azure deployment logic but with custom image
    const { azureVerifiedDeployment } = await import('./azure-verified-deployment');
    
    return await azureVerifiedDeployment.deployContainer({
      name: spec.name,
      image: imageName,
      resourceGroup: spec.resourceGroup,
      location: spec.location,
      cpu: 1,
      memory: 1.5,
      ports: spec.ports,
      environmentVariables: spec.environmentVariables
    });
  }

  private async deployWithCodeInjection(spec: CodeDeploymentSpec): Promise<any> {
    const { azureVerifiedDeployment } = await import('./azure-verified-deployment');
    
    if (spec.codeType === 'javascript') {
      // Create a multi-stage deployment using init containers
      const deployment = await azureVerifiedDeployment.deployContainer({
        name: spec.name,
        image: 'node:18-alpine',
        resourceGroup: spec.resourceGroup,
        location: spec.location,
        cpu: 1,
        memory: 1.5,
        ports: spec.ports,
        environmentVariables: {
          ...spec.environmentVariables,
          'USER_CODE': Buffer.from(spec.code).toString('base64'),
          'PACKAGE_JSON': Buffer.from(JSON.stringify({
            name: spec.name,
            version: '1.0.0',
            main: 'app.js',
            dependencies: { express: '^4.18.0' }
          })).toString('base64')
        },
        command: [
          'sh', '-c', 
          'echo $PACKAGE_JSON | base64 -d > package.json && ' +
          'npm install && ' +
          'echo $USER_CODE | base64 -d > app.js && ' +
          'node app.js'
        ]
      });

      // Return deployment with proper status
      return {
        ...deployment,
        url: deployment.properties?.ipAddress?.ip ? `http://${deployment.properties.ipAddress.ip}:${spec.ports[0]}` : null,
        publicIp: deployment.properties?.ipAddress?.ip
      };
    }
    
    if (spec.codeType === 'html') {
      const deployment = await azureVerifiedDeployment.deployContainer({
        name: spec.name,
        image: 'nginx:alpine',
        resourceGroup: spec.resourceGroup,
        location: spec.location,
        cpu: 1,
        memory: 1.5,
        ports: spec.ports,
        environmentVariables: {
          ...spec.environmentVariables,
          'HTML_CONTENT': Buffer.from(spec.code).toString('base64')
        },
        command: [
          'sh', '-c',
          'echo $HTML_CONTENT | base64 -d > /usr/share/nginx/html/index.html && nginx -g "daemon off;"'
        ]
      });

      return {
        ...deployment,
        url: deployment.properties?.ipAddress?.ip ? `http://${deployment.properties.ipAddress.ip}` : null,
        publicIp: deployment.properties?.ipAddress?.ip
      };
    }
    
    // Generic fallback
    const deployment = await azureVerifiedDeployment.deployContainer({
      name: spec.name,
      image: 'alpine:latest',
      resourceGroup: spec.resourceGroup,
      location: spec.location,
      cpu: 1,
      memory: 1.5,
      ports: spec.ports,
      environmentVariables: {
        ...spec.environmentVariables,
        'USER_CODE': spec.code
      }
    });

    return {
      ...deployment,
      url: deployment.properties?.ipAddress?.ip ? `http://${deployment.properties.ipAddress.ip}` : null,
      publicIp: deployment.properties?.ipAddress?.ip
    };
  }
}

export const azureCodeDeployment = new AzureCodeDeployment();