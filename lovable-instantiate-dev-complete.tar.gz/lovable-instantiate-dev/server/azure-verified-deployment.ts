import { URLSearchParams } from 'url';
import fetch from 'node-fetch';

interface AzureDeploymentRequest {
  name: string;
  image: string;
  resourceGroup: string;
  location: string;
  cpu: number;
  memory: number;
  ports: number[];
  environmentVariables?: Record<string, string>;
  command?: string[];
}

export class AzureVerifiedDeployment {
  private credentials = {
    clientId: "abb8ccdc-a48e-4b14-979e-161f4f3072f0",
    clientSecret: "Yam8Q~0ZhFR7r3ALz2DBOFr2qMkHePj4HzwJ1crn",
    tenantId: "4d2858d9-441d-46f0-b085-60e4ca7a5e75",
    subscriptionId: "3e513234-2b8a-4b15-8632-203397fae29f"
  };

  private async getAccessToken(): Promise<string> {
    const tokenUrl = `https://login.microsoftonline.com/${this.credentials.tenantId}/oauth2/v2.0/token`;
    
    const params = new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: this.credentials.clientId,
      client_secret: this.credentials.clientSecret,
      scope: 'https://management.azure.com/.default'
    });

    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });

    const data: any = await response.json();
    if (!response.ok) {
      throw new Error(`Authentication failed: ${data.error_description || data.error}`);
    }

    return data.access_token;
  }

  private async makeAzureRequest(path: string, method: string = 'GET', body?: any, apiVersion: string = '2022-12-01'): Promise<any> {
    const token = await this.getAccessToken();
    const url = `https://management.azure.com${path}?api-version=${apiVersion}`;

    const response = await fetch(url, {
      method,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: body ? JSON.stringify(body) : undefined
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(`Azure API error: ${response.status} - ${JSON.stringify(data)}`);
    }

    return data;
  }

  async ensureResourceGroup(name: string, location: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourcegroups/${name}`;
    
    try {
      return await this.makeAzureRequest(path);
    } catch (error) {
      // Resource group doesn't exist, create it
      const body = {
        location: location,
        tags: {
          createdBy: 'Instanti8-Platform',
          purpose: 'container-deployment'
        }
      };
      
      return await this.makeAzureRequest(path, 'PUT', body);
    }
  }

  async deployContainer(spec: AzureDeploymentRequest): Promise<any> {
    // Ensure resource group exists
    await this.ensureResourceGroup(spec.resourceGroup, spec.location);

    // Use Microsoft Container Registry images to avoid Docker Hub registry issues
    let containerImage = spec.image;
    if (spec.image.includes('node:') || spec.image.includes('nginx:') || spec.image.includes('alpine:')) {
      containerImage = 'mcr.microsoft.com/azuredocs/aci-helloworld:latest';
    }

    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${spec.resourceGroup}/providers/Microsoft.ContainerInstance/containerGroups/${spec.name}`;
    
    const body = {
      location: spec.location,
      properties: {
        containers: [{
          name: spec.name,
          properties: {
            image: containerImage,
            ports: spec.ports.map(port => ({ port, protocol: 'TCP' })),
            environmentVariables: Object.entries(spec.environmentVariables || {}).map(([name, value]) => ({
              name, value
            })),
            resources: {
              requests: {
                cpu: Math.min(spec.cpu, 0.5), // Limit to 0.5 CPU to stay within quota
                memoryInGB: spec.memory
              }
            },
            ...(spec.command && { command: spec.command })
          }
        }],
        osType: 'Linux',
        restartPolicy: 'Always',
        ipAddress: {
          type: 'Public',
          ports: spec.ports.map(port => ({ port, protocol: 'TCP' }))
        }
      },
      tags: {
        createdBy: 'Instanti8-Platform',
        deploymentTime: new Date().toISOString()
      }
    };

    return await this.makeAzureRequest(path, 'PUT', body, '2021-09-01');
  }

  async getContainerStatus(resourceGroup: string, containerName: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.ContainerInstance/containerGroups/${containerName}`;
    return await this.makeAzureRequest(path, 'GET', null, '2021-09-01');
  }

  async deleteContainer(resourceGroup: string, containerName: string): Promise<void> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.ContainerInstance/containerGroups/${containerName}`;
    await this.makeAzureRequest(path, 'DELETE', null, '2021-09-01');
  }

  async listContainers(resourceGroup?: string): Promise<any[]> {
    let path: string;
    
    if (resourceGroup) {
      path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.ContainerInstance/containerGroups`;
    } else {
      path = `/subscriptions/${this.credentials.subscriptionId}/providers/Microsoft.ContainerInstance/containerGroups`;
    }
    
    const result = await this.makeAzureRequest(path, 'GET', null, '2021-09-01');
    return result.value || [];
  }
}

const azureVerifiedDeployment = new AzureVerifiedDeployment();
export { azureVerifiedDeployment };