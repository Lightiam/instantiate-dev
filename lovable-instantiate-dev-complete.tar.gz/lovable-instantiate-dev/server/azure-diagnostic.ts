import { getAzureService } from './azure-service';

export interface AzureDiagnostic {
  timestamp: string;
  status: 'success' | 'error' | 'warning';
  test: string;
  message: string;
  details?: any;
}

export class AzureDiagnosticService {
  async runCompleteDiagnostic(): Promise<AzureDiagnostic[]> {
    const results: AzureDiagnostic[] = [];
    const timestamp = new Date().toISOString();

    // Test 1: Environment Variables
    results.push(this.testEnvironmentVariables(timestamp));

    // Test 2: Azure Service Initialization
    try {
      const azureService = getAzureService();
      results.push({
        timestamp,
        status: 'success',
        test: 'Azure Service Initialization',
        message: 'Azure service instance created successfully'
      });

      // Test 3: Authentication
      await this.testAuthentication(results, timestamp, azureService);

      // Test 4: Subscription Access
      await this.testSubscriptionAccess(results, timestamp, azureService);

    } catch (error: any) {
      results.push({
        timestamp,
        status: 'error',
        test: 'Azure Service Initialization',
        message: `Failed to initialize Azure service: ${error.message}`,
        details: error
      });
    }

    return results;
  }

  private testEnvironmentVariables(timestamp: string): AzureDiagnostic {
    const clientId = process.env.AZURE_CLIENT_ID || "b55f930f-537f-4865-bbc5-43dd4e1609f9";
    const clientSecret = process.env.AZURE_CLIENT_SECRET || "1kt8Q~~KcPq6tkJQYsBSG6p6~Vua1SbDBbPDcbMd";
    const tenantId = process.env.AZURE_TENANT_ID || "4d2858d9-441d-46f0-b085-60e4ca7a5e75";
    const subscriptionId = process.env.AZURE_SUBSCRIPTION_ID || "3e513234-2b8a-4b15-8632-203397fae29f";

    const missing = [];
    if (!clientId) missing.push('AZURE_CLIENT_ID');
    if (!clientSecret) missing.push('AZURE_CLIENT_SECRET');
    if (!tenantId) missing.push('AZURE_TENANT_ID');
    if (!subscriptionId) missing.push('AZURE_SUBSCRIPTION_ID');

    if (missing.length > 0) {
      return {
        timestamp,
        status: 'error',
        test: 'Environment Variables',
        message: `Missing Azure environment variables: ${missing.join(', ')}`,
        details: { missing }
      };
    }

    return {
      timestamp,
      status: 'success',
      test: 'Environment Variables',
      message: 'All required Azure environment variables are present',
      details: {
        clientId: clientId?.substring(0, 8) + '...',
        tenantId: tenantId?.substring(0, 8) + '...',
        subscriptionId: subscriptionId?.substring(0, 8) + '...',
        hasClientSecret: !!clientSecret
      }
    };
  }

  private async testAuthentication(results: AzureDiagnostic[], timestamp: string, azureService: any) {
    try {
      const { ClientSecretCredential } = await import('@azure/identity');
      const config = {
        clientId: process.env.AZURE_CLIENT_ID || "b55f930f-537f-4865-bbc5-43dd4e1609f9",
        clientSecret: process.env.AZURE_CLIENT_SECRET || "1kt8Q~~KcPq6tkJQYsBSG6p6~Vua1SbDBbPDcbMd",
        tenantId: process.env.AZURE_TENANT_ID || "4d2858d9-441d-46f0-b085-60e4ca7a5e75",
      };

      const credential = new ClientSecretCredential(
        config.tenantId,
        config.clientId,
        config.clientSecret
      );

      // Test token acquisition
      const token = await credential.getToken(['https://management.azure.com/.default']);
      
      results.push({
        timestamp,
        status: 'success',
        test: 'Azure Authentication',
        message: 'Successfully authenticated with Azure',
        details: {
          tokenExpires: new Date(token.expiresOnTimestamp),
          scopes: ['https://management.azure.com/.default']
        }
      });
    } catch (error: any) {
      results.push({
        timestamp,
        status: 'error',
        test: 'Azure Authentication',
        message: `Authentication failed: ${error.message}`,
        details: {
          errorCode: error.code,
          errorName: error.name,
          isClientSecretError: error.message?.includes('AADSTS7000215'),
          isClientIdError: error.message?.includes('AADSTS700016'),
          isTenantError: error.message?.includes('AADSTS90002')
        }
      });
    }
  }

  private async testSubscriptionAccess(results: AzureDiagnostic[], timestamp: string, azureService: any) {
    try {
      const { SubscriptionClient } = await import('@azure/arm-subscriptions');
      const { ClientSecretCredential } = await import('@azure/identity');
      
      const config = {
        clientId: process.env.AZURE_CLIENT_ID || "b55f930f-537f-4865-bbc5-43dd4e1609f9",
        clientSecret: process.env.AZURE_CLIENT_SECRET || "1kt8Q~~KcPq6tkJQYsBSG6p6~Vua1SbDBbPDcbMd",
        tenantId: process.env.AZURE_TENANT_ID || "4d2858d9-441d-46f0-b085-60e4ca7a5e75",
        subscriptionId: process.env.AZURE_SUBSCRIPTION_ID || "3e513234-2b8a-4b15-8632-203397fae29f"
      };

      const credential = new ClientSecretCredential(
        config.tenantId,
        config.clientId,
        config.clientSecret
      );

      const subscriptionClient = new SubscriptionClient(credential);
      const subscription = await subscriptionClient.subscriptions.get(config.subscriptionId);

      results.push({
        timestamp,
        status: 'success',
        test: 'Subscription Access',
        message: `Successfully accessed subscription: ${subscription.displayName}`,
        details: {
          subscriptionId: subscription.subscriptionId,
          displayName: subscription.displayName,
          state: subscription.state,
          tenantId: subscription.tenantId
        }
      });
    } catch (error: any) {
      results.push({
        timestamp,
        status: 'error',
        test: 'Subscription Access',
        message: `Failed to access subscription: ${error.message}`,
        details: {
          errorCode: error.code,
          statusCode: error.statusCode,
          isPermissionError: error.message?.includes('AuthorizationFailed') || error.message?.includes('Forbidden')
        }
      });
    }
  }

  async testContainerDeployment(containerSpec: any): Promise<AzureDiagnostic> {
    const timestamp = new Date().toISOString();
    
    try {
      const azureService = getAzureService();
      const result = await azureService.createContainer(containerSpec);
      
      return {
        timestamp,
        status: 'success',
        test: 'Container Deployment',
        message: `Container deployment successful: ${result.name}`,
        details: result
      };
    } catch (error: any) {
      return {
        timestamp,
        status: 'error',
        test: 'Container Deployment',
        message: `Container deployment failed: ${error.message}`,
        details: {
          error: error.message,
          containerSpec
        }
      };
    }
  }
}

export const azureDiagnostic = new AzureDiagnosticService();