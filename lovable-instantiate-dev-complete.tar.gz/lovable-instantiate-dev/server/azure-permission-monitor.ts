import https from 'https';

export class AzurePermissionMonitor {
  private subscriptionId: string;
  private tenantId: string;
  private clientId: string;
  private clientSecret: string;

  constructor() {
    this.subscriptionId = process.env.AZURE_SUBSCRIPTION_ID!;
    this.tenantId = process.env.AZURE_TENANT_ID!;
    this.clientId = process.env.AZURE_CLIENT_ID!;
    this.clientSecret = process.env.AZURE_CLIENT_SECRET!;
  }

  private makeRequest(path: string, token: string): Promise<any> {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'management.azure.com',
        port: 443,
        path: path,
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
          try {
            const response = JSON.parse(data);
            if (res.statusCode === 200) {
              resolve(response);
            } else {
              reject(new Error(`HTTP ${res.statusCode}: ${response.error?.message || data}`));
            }
          } catch (error) {
            reject(new Error(`Parse error: ${data}`));
          }
        });
      });

      req.on('error', reject);
      req.end();
    });
  }

  async checkPermissions(): Promise<{
    hasSubscriptionAccess: boolean;
    canListResourceGroups: boolean;
    canCreateResourceGroups: boolean;
    canCreateContainers: boolean;
    details: string[];
  }> {
    const details: string[] = [];
    
    try {
      // Get access token
      const token = await this.getAccessToken();
      details.push('✅ Authentication successful');

      // Test subscription access
      try {
        await this.makeRequest(`/subscriptions/${this.subscriptionId}?api-version=2020-01-01`, token);
        details.push('✅ Subscription access confirmed');
      } catch (error: any) {
        details.push(`❌ Subscription access failed: ${error.message}`);
        return { hasSubscriptionAccess: false, canListResourceGroups: false, canCreateResourceGroups: false, canCreateContainers: false, details };
      }

      // Test resource groups listing
      let canListResourceGroups = false;
      try {
        await this.makeRequest(`/subscriptions/${this.subscriptionId}/resourcegroups?api-version=2021-04-01`, token);
        canListResourceGroups = true;
        details.push('✅ Resource groups listing permissions confirmed');
      } catch (error: any) {
        details.push(`❌ Cannot list resource groups: ${error.message}`);
      }

      // Test resource group creation
      let canCreateResourceGroups = false;
      try {
        // Check providers registration for resource management
        await this.makeRequest(`/subscriptions/${this.subscriptionId}/providers/Microsoft.Resources?api-version=2021-04-01`, token);
        canCreateResourceGroups = true;
        details.push('✅ Resource group creation permissions confirmed');
      } catch (error: any) {
        details.push(`❌ Cannot create resource groups: ${error.message}`);
      }

      // Test container instance permissions
      let canCreateContainers = false;
      try {
        await this.makeRequest(`/subscriptions/${this.subscriptionId}/providers/Microsoft.ContainerInstance?api-version=2021-09-01`, token);
        canCreateContainers = true;
        details.push('✅ Container instance permissions confirmed');
      } catch (error: any) {
        details.push(`❌ Container instance permissions missing: ${error.message}`);
      }

      return {
        hasSubscriptionAccess: true,
        canListResourceGroups,
        canCreateResourceGroups,
        canCreateContainers,
        details
      };

    } catch (error: any) {
      details.push(`❌ Authentication failed: ${error.message}`);
      return { hasSubscriptionAccess: false, canListResourceGroups: false, canCreateResourceGroups: false, canCreateContainers: false, details };
    }
  }

  async testDeployment(): Promise<{ success: boolean; message: string; details: string[] }> {
    const details: string[] = [];
    
    try {
      const token = await this.getAccessToken();
      details.push('Starting deployment test...');

      // Create test resource group
      const testRgName = `instanti8-test-${Date.now()}`;
      const createRgPath = `/subscriptions/${this.subscriptionId}/resourcegroups/${testRgName}?api-version=2021-04-01`;
      
      const rgBody = JSON.stringify({
        location: 'eastus',
        tags: {
          'created-by': 'instanti8-permission-test',
          'test-timestamp': new Date().toISOString()
        }
      });

      await new Promise((resolve, reject) => {
        const options = {
          hostname: 'management.azure.com',
          port: 443,
          path: createRgPath,
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'Content-Length': rgBody.length
          }
        };

        const req = https.request(options, (res) => {
          let data = '';
          res.on('data', (chunk) => data += chunk);
          res.on('end', () => {
            if (res.statusCode === 200 || res.statusCode === 201) {
              resolve(data);
            } else {
              reject(new Error(`Resource group creation failed: ${res.statusCode} - ${data}`));
            }
          });
        });

        req.on('error', reject);
        req.write(rgBody);
        req.end();
      });

      details.push('✅ Test resource group created successfully');

      // Clean up test resource group
      await new Promise((resolve, reject) => {
        const deleteOptions = {
          hostname: 'management.azure.com',
          port: 443,
          path: createRgPath,
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        };

        const req = https.request(deleteOptions, (res) => {
          let data = '';
          res.on('data', (chunk) => data += chunk);
          res.on('end', () => {
            if (res.statusCode === 200 || res.statusCode === 202 || res.statusCode === 204) {
              resolve(data);
            } else {
              reject(new Error(`Resource group deletion failed: ${res.statusCode} - ${data}`));
            }
          });
        });

        req.on('error', reject);
        req.end();
      });

      details.push('✅ Test resource group cleaned up');
      details.push('🎉 Full Azure deployment permissions confirmed');

      return {
        success: true,
        message: 'Azure permissions are working correctly',
        details
      };

    } catch (error: any) {
      details.push(`❌ Deployment test failed: ${error.message}`);
      return {
        success: false,
        message: 'Azure permissions insufficient for deployment',
        details
      };
    }
  }

  private async getAccessToken(): Promise<string> {
    const postData = `client_id=${encodeURIComponent(this.clientId)}&client_secret=${encodeURIComponent(this.clientSecret)}&scope=${encodeURIComponent('https://management.azure.com/.default')}&grant_type=client_credentials`;

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'login.microsoftonline.com',
        port: 443,
        path: `/${this.tenantId}/oauth2/v2.0/token`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': postData.length
        }
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
          try {
            const response = JSON.parse(data);
            if (response.access_token) {
              resolve(response.access_token);
            } else {
              reject(new Error(`Token acquisition failed: ${data}`));
            }
          } catch (error) {
            reject(new Error(`Token parsing failed: ${data}`));
          }
        });
      });

      req.on('error', reject);
      req.write(postData);
      req.end();
    });
  }

  async monitor(): Promise<void> {
    console.log('🔍 Starting Azure permission monitoring...');
    
    const checkInterval = setInterval(async () => {
      try {
        const permissions = await this.checkPermissions();
        
        if (permissions.hasSubscriptionAccess && permissions.canCreateResourceGroups && permissions.canCreateContainers) {
          console.log('🎉 Azure permissions are ready!');
          console.log('Details:', permissions.details.join('\n'));
          clearInterval(checkInterval);
          
          // Run deployment test
          const deploymentTest = await this.testDeployment();
          console.log('Deployment test result:', deploymentTest.message);
          console.log('Test details:', deploymentTest.details.join('\n'));
        } else {
          console.log('⏳ Waiting for Azure permissions to propagate...');
          console.log('Current status:', permissions.details.join('\n'));
        }
      } catch (error: any) {
        console.error('❌ Permission check failed:', error.message);
      }
    }, 30000); // Check every 30 seconds

    // Stop monitoring after 10 minutes
    setTimeout(() => {
      clearInterval(checkInterval);
      console.log('🛑 Azure permission monitoring stopped');
    }, 600000);
  }
}

export const azurePermissionMonitor = new AzurePermissionMonitor();