import { URLSearchParams } from 'url';
import fetch from 'node-fetch';

interface AzureStaticAppRequest {
  name: string;
  code: string;
  codeType: 'javascript' | 'python' | 'html';
  resourceGroup: string;
  location: string;
}

export class AzureStaticApps {
  private credentials = {
    clientId: "abb8ccdc-a48e-4b14-979e-161f4f3072f0",
    clientSecret: "Yam8Q~0ZhFR7r3ALz2DBOFr2qMkHePj4HzwJ1crn",
    tenantId: "4d2858d9-441d-46f0-b085-60e4ca7a5e75",
    subscriptionId: "3e513234-2b8a-4b15-8632-203397fae29f"
  };

  private async getAccessToken(): Promise<string> {
    const tokenUrl = `https://login.microsoftonline.com/${this.credentials.tenantId}/oauth2/v2.0/token`;
    
    const params = new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: this.credentials.clientId,
      client_secret: this.credentials.clientSecret,
      scope: 'https://management.azure.com/.default'
    });

    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });

    const data: any = await response.json();
    if (!response.ok) {
      throw new Error(`Azure authentication failed: ${JSON.stringify(data)}`);
    }

    return data.access_token;
  }

  private async makeAzureRequest(path: string, method: string = 'GET', body: any = null, apiVersion: string = '2022-03-01'): Promise<any> {
    const token = await this.getAccessToken();
    const url = `https://management.azure.com${path}?api-version=${apiVersion}`;
    
    const headers: Record<string, string> = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    const options: any = {
      method,
      headers,
      ...(body && { body: JSON.stringify(body) })
    };

    const response = await fetch(url, options as any);
    const responseData = await response.text();
    
    if (!response.ok) {
      throw new Error(`Azure API error: ${response.status} - ${responseData}`);
    }

    return responseData ? JSON.parse(responseData) : {};
  }

  async deployStaticApp(spec: AzureStaticAppRequest): Promise<any> {
    // 1. Ensure resource group exists
    await this.ensureResourceGroup(spec.resourceGroup, spec.location);

    // 2. Create Static Web App
    const staticApp = await this.createStaticWebApp(spec);

    return {
      name: spec.name,
      resourceGroup: spec.resourceGroup,
      url: `https://${spec.name}.azurestaticapps.net`,
      status: 'Deployed',
      provider: 'azure-static-apps',
      codeDeployed: true
    };
  }

  private async ensureResourceGroup(resourceGroup: string, location: string): Promise<void> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}`;
    
    try {
      await this.makeAzureRequest(path, 'GET', null, '2021-04-01');
    } catch (error) {
      const body = {
        location: location,
        tags: {
          createdBy: 'Instanti8-Platform',
          purpose: 'static-web-app'
        }
      };
      
      await this.makeAzureRequest(path, 'PUT', body, '2021-04-01');
    }
  }

  private async createStaticWebApp(spec: AzureStaticAppRequest): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${spec.resourceGroup}/providers/Microsoft.Web/staticSites/${spec.name}`;
    
    const body = {
      location: spec.location,
      sku: {
        name: 'Free',
        tier: 'Free'
      },
      properties: {
        repositoryUrl: 'https://github.com/instanti8/placeholder-repo',
        branch: 'main',
        buildProperties: {
          appLocation: '/',
          apiLocation: 'api',
          outputLocation: 'dist'
        },
        allowConfigFileUpdates: true,
        enterpriseGradeCdnStatus: 'Disabled'
      },
      tags: {
        'Created-By': 'Instanti8-Platform',
        'Deployment-Type': 'Code-Deployment',
        'Source-Code-Type': spec.codeType,
        'User-Code': Buffer.from(spec.code.substring(0, 200)).toString('base64')
      }
    };
    
    return await this.makeAzureRequest(path, 'PUT', body, '2022-03-01');
  }

  async getStaticAppStatus(resourceGroup: string, appName: string): Promise<any> {
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Web/staticSites/${appName}`;
    return await this.makeAzureRequest(path);
  }

  async listStaticApps(resourceGroup?: string): Promise<any[]> {
    let path: string;
    
    if (resourceGroup) {
      path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.Web/staticSites`;
    } else {
      path = `/subscriptions/${this.credentials.subscriptionId}/providers/Microsoft.Web/staticSites`;
    }
    
    const result = await this.makeAzureRequest(path);
    return result.value || [];
  }
}

export const azureStaticApps = new AzureStaticApps();