export interface GCPDiagnostic {
  timestamp: string;
  status: 'success' | 'error' | 'warning';
  test: string;
  message: string;
  details?: any;
}

export class GCPDiagnosticService {
  async runCompleteDiagnostic(): Promise<GCPDiagnostic[]> {
    const results: GCPDiagnostic[] = [];
    const timestamp = new Date().toISOString();

    // Test environment variables
    results.push(this.testEnvironmentVariables(timestamp));

    try {
      const { getGCPService } = await import('./gcp-service-simple');
      const gcpService = getGCPService();

      // Test authentication
      await this.testAuthentication(results, timestamp, gcpService);

      // Test project access
      await this.testProjectAccess(results, timestamp, gcpService);

      // Test service APIs
      await this.testServiceAPIs(results, timestamp, gcpService);

    } catch (error: any) {
      results.push({
        timestamp,
        status: 'error',
        test: 'GCP Service Initialization',
        message: `Failed to initialize GCP service: ${error.message}`,
        details: { error: error.message }
      });
    }

    return results;
  }

  private testEnvironmentVariables(timestamp: string): GCPDiagnostic {
    const projectId = process.env.GCP_PROJECT_ID;
    const serviceAccountKey = process.env.GCP_SERVICE_ACCOUNT_KEY;

    if (!projectId) {
      return {
        timestamp,
        status: 'error',
        test: 'Environment Variables',
        message: 'GCP_PROJECT_ID environment variable is missing',
        details: { missingVars: ['GCP_PROJECT_ID'] }
      };
    }

    const details: any = {
      projectId: projectId.substring(0, 10) + '...',
      hasServiceAccountKey: !!serviceAccountKey
    };

    if (serviceAccountKey) {
      try {
        const keyData = JSON.parse(serviceAccountKey);
        details.serviceAccountEmail = keyData.client_email?.substring(0, 20) + '...';
        details.keyType = keyData.type;
      } catch (error) {
        return {
          timestamp,
          status: 'error',
          test: 'Environment Variables',
          message: 'GCP_SERVICE_ACCOUNT_KEY is not valid JSON',
          details: { error: 'Invalid JSON format' }
        };
      }
    }

    return {
      timestamp,
      status: 'success',
      test: 'Environment Variables',
      message: 'Required GCP environment variables are present',
      details
    };
  }

  private async testAuthentication(results: GCPDiagnostic[], timestamp: string, gcpService: any) {
    try {
      const authResult = await gcpService.validateAuthentication();
      results.push({
        timestamp,
        status: 'success',
        test: 'GCP Authentication',
        message: 'Successfully authenticated with Google Cloud Platform',
        details: {
          projectId: authResult.projectId,
          clientEmail: authResult.clientEmail
        }
      });
    } catch (error: any) {
      results.push({
        timestamp,
        status: 'error',
        test: 'GCP Authentication',
        message: `Authentication failed: ${error.message}`,
        details: { error: error.message }
      });
    }
  }

  private async testProjectAccess(results: GCPDiagnostic[], timestamp: string, gcpService: any) {
    try {
      const project = await gcpService.getProject();
      results.push({
        timestamp,
        status: 'success',
        test: 'Project Access',
        message: 'Successfully accessed GCP project',
        details: {
          projectId: project.projectId,
          projectNumber: project.projectNumber,
          name: project.name,
          state: project.state
        }
      });
    } catch (error: any) {
      results.push({
        timestamp,
        status: 'error',
        test: 'Project Access',
        message: `Failed to access project: ${error.message}`,
        details: { error: error.message }
      });
    }
  }

  private async testServiceAPIs(results: GCPDiagnostic[], timestamp: string, gcpService: any) {
    // Test Compute Engine API
    try {
      await gcpService.listComputeInstances();
      results.push({
        timestamp,
        status: 'success',
        test: 'Compute Engine API',
        message: 'Compute Engine API is accessible',
        details: { service: 'compute.googleapis.com' }
      });
    } catch (error: any) {
      results.push({
        timestamp,
        status: 'warning',
        test: 'Compute Engine API',
        message: `Compute Engine API access limited: ${error.message}`,
        details: { error: error.message }
      });
    }

    // Test Cloud Storage API
    try {
      await gcpService.listStorageBuckets();
      results.push({
        timestamp,
        status: 'success',
        test: 'Cloud Storage API',
        message: 'Cloud Storage API is accessible',
        details: { service: 'storage.googleapis.com' }
      });
    } catch (error: any) {
      results.push({
        timestamp,
        status: 'warning',
        test: 'Cloud Storage API',
        message: `Cloud Storage API access limited: ${error.message}`,
        details: { error: error.message }
      });
    }

    // Test Pub/Sub API
    try {
      await gcpService.listPubSubTopics();
      results.push({
        timestamp,
        status: 'success',
        test: 'Pub/Sub API',
        message: 'Pub/Sub API is accessible',
        details: { service: 'pubsub.googleapis.com' }
      });
    } catch (error: any) {
      results.push({
        timestamp,
        status: 'warning',
        test: 'Pub/Sub API',
        message: `Pub/Sub API access limited: ${error.message}`,
        details: { error: error.message }
      });
    }
  }

  async testComputeDeployment(instanceSpec: any): Promise<GCPDiagnostic> {
    const timestamp = new Date().toISOString();
    
    try {
      const { getGCPService } = await import('./gcp-service-simple');
      const gcpService = getGCPService();
      
      const result = await gcpService.createComputeInstance(instanceSpec);
      
      return {
        timestamp,
        status: 'success',
        test: 'Compute Instance Deployment',
        message: 'Successfully created compute instance',
        details: {
          instanceId: result.id,
          instanceName: result.name,
          zone: result.zone,
          status: result.status
        }
      };
    } catch (error: any) {
      return {
        timestamp,
        status: 'error',
        test: 'Compute Instance Deployment',
        message: `Failed to create compute instance: ${error.message}`,
        details: { error: error.message }
      };
    }
  }
}

export const gcpDiagnostic = new GCPDiagnosticService();