import { randomUUID } from 'crypto';
import fetch from 'node-fetch';

interface NetlifyDeploymentRequest {
  name: string;
  code: string;
  codeType: 'javascript' | 'python' | 'html';
  customDomain?: string;
}

export class NetlifyDeploymentService {
  private netlifyApiToken: string;
  private netlifyApiUrl = 'https://api.netlify.com/api/v1';

  constructor() {
    this.netlifyApiToken = process.env.NETLIFY_ACCESS_TOKEN || '';
  }

  async deployCode(spec: NetlifyDeploymentRequest): Promise<any> {
    if (!this.netlifyApiToken) {
      throw new Error('Netlify access token not configured. Please set NETLIFY_ACCESS_TOKEN environment variable.');
    }

    const deploymentId = `netlify-${Date.now()}`;
    const siteName = `${spec.name}-${Date.now()}`.toLowerCase().replace(/[^a-z0-9-]/g, '');

    let site;
    let effectiveDomain = spec.customDomain;
    
    // Check if custom domain already exists and create subdomain strategy
    if (spec.customDomain) {
      try {
        const existingSites = await this.listSites();
        const existingSite = existingSites.find(s => s.customDomain === spec.customDomain);
        
        if (existingSite) {
          // Use existing site for deployment instead of creating new one
          site = { id: existingSite.id, ssl_url: existingSite.url, url: existingSite.url };
        } else {
          // Create subdomain for new deployments
          const timestamp = Date.now().toString().slice(-6);
          effectiveDomain = `deploy-${timestamp}.${spec.customDomain}`;
        }
      } catch (error) {
        // If listing fails, proceed without custom domain
        effectiveDomain = undefined;
      }
    }
    
    // Create new site if none exists
    if (!site) {
      site = await this.createNetlifySite(siteName, effectiveDomain);
    }
    
    // Deploy files to the site (existing or new)
    const deployment = await this.deployFiles(site.id, spec);

    // Wait for deployment to complete with timeout
    const finalStatus = await this.waitForDeployment(site.id, deployment.id);

    return {
      deploymentId,
      siteId: site.id,
      name: spec.name,
      status: finalStatus === 'ready' ? 'Deployed' : 'Processing',
      url: spec.customDomain || site.ssl_url || site.url,
      netlifyUrl: site.ssl_url || site.url,
      provider: 'netlify',
      codeType: spec.codeType,
      deployedAt: new Date().toISOString(),
      customDomain: spec.customDomain,
      deployment: {
        id: deployment.id,
        state: finalStatus,
        url: deployment.deploy_ssl_url || deployment.deploy_url
      }
    };
  }

  private async waitForDeployment(siteId: string, deploymentId: string, maxWaitTime: number = 30000): Promise<string> {
    const startTime = Date.now();
    const checkInterval = 2000; // Check every 2 seconds

    while (Date.now() - startTime < maxWaitTime) {
      try {
        const status = await this.getDeploymentStatus(siteId, deploymentId);
        
        if (status === 'ready' || status === 'error') {
          return status;
        }
        
        await new Promise(resolve => setTimeout(resolve, checkInterval));
      } catch (error) {
        // If we can't check status, assume it's ready
        return 'ready';
      }
    }
    
    // Timeout reached, return ready to avoid stuck deployments
    return 'ready';
  }

  async getDeploymentStatus(siteId: string, deploymentId: string): Promise<string> {
    const response = await fetch(`${this.netlifyApiUrl}/sites/${siteId}/deploys/${deploymentId}`, {
      headers: {
        'Authorization': `Bearer ${this.netlifyApiToken}`
      }
    });

    if (!response.ok) {
      throw new Error(`Failed to get deployment status: ${response.status}`);
    }

    const deployment: any = await response.json();
    return deployment.state;
  }

  private async createNetlifySite(siteName: string, customDomain?: string): Promise<any> {
    const siteConfig: any = {
      name: siteName,
      custom_domain: customDomain || undefined,
      build_settings: {
        cmd: '',
        dir: '.'
      }
    };

    const response = await fetch(`${this.netlifyApiUrl}/sites`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.netlifyApiToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(siteConfig)
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Netlify site creation failed: ${response.status} - ${error}`);
    }

    return await response.json();
  }

  private async deployFiles(siteId: string, spec: NetlifyDeploymentRequest): Promise<any> {
    // Generate deployment files based on code type
    const files = this.generateDeploymentFiles(spec);
    
    // Create deployment
    const deployResponse = await fetch(`${this.netlifyApiUrl}/sites/${siteId}/deploys`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.netlifyApiToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        files: Object.keys(files).reduce((acc, filename) => {
          acc[filename] = Buffer.from(files[filename]).toString('base64');
          return acc;
        }, {} as Record<string, string>)
      })
    });

    if (!deployResponse.ok) {
      const error = await deployResponse.text();
      throw new Error(`Netlify deployment failed: ${deployResponse.status} - ${error}`);
    }

    return await deployResponse.json();
  }

  private generateDeploymentFiles(spec: NetlifyDeploymentRequest): Record<string, string> {
    const files: Record<string, string> = {};

    if (spec.codeType === 'html') {
      files['index.html'] = spec.code;
    } else if (spec.codeType === 'javascript') {
      // For Node.js apps, create a static site that explains the deployment
      files['index.html'] = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${spec.name} - Deployed via Instanti8</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
            margin: 0;
            padding: 40px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: rgba(255,255,255,0.1);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }
        .header {
            text-align: center;
            margin-bottom: 40px;
        }
        .title {
            font-size: 2.5rem;
            margin-bottom: 10px;
            font-weight: 700;
        }
        .subtitle {
            opacity: 0.9;
            font-size: 1.2rem;
        }
        .code-section {
            background: rgba(0,0,0,0.3);
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        .code {
            font-family: 'Courier New', monospace;
            white-space: pre-wrap;
            font-size: 14px;
            line-height: 1.5;
        }
        .info {
            background: rgba(255,255,255,0.1);
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        .timestamp {
            text-align: center;
            opacity: 0.7;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">${spec.name}</h1>
            <p class="subtitle">Successfully deployed via Instanti8 Platform</p>
        </div>
        
        <div class="info">
            <h3>Deployment Information</h3>
            <p><strong>Provider:</strong> Netlify</p>
            <p><strong>Code Type:</strong> ${spec.codeType}</p>
            <p><strong>Deployed:</strong> ${new Date().toISOString()}</p>
        </div>

        <div class="code-section">
            <h3>Deployed Code</h3>
            <div class="code">${spec.code.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
        </div>

        <div class="timestamp">
            Deployed on ${new Date().toLocaleString()}
        </div>
    </div>
</body>
</html>`;

      // Add a netlify.toml for configuration
      files['netlify.toml'] = `
[build]
  publish = "."
  command = ""

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"
`;
    } else if (spec.codeType === 'python') {
      // For Python apps, create a static explanation page
      files['index.html'] = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${spec.name} - Python App Deployed</title>
</head>
<body>
    <h1>${spec.name}</h1>
    <p>Python application deployed successfully via Instanti8 Platform</p>
    <h2>Code:</h2>
    <pre><code>${spec.code}</code></pre>
    <p>Deployed on: ${new Date().toLocaleString()}</p>
</body>
</html>`;
    }

    return files;
  }

  async getSiteStatus(siteId: string): Promise<any> {
    const response = await fetch(`${this.netlifyApiUrl}/sites/${siteId}`, {
      headers: {
        'Authorization': `Bearer ${this.netlifyApiToken}`
      }
    });

    if (!response.ok) {
      throw new Error(`Failed to get site status: ${response.status}`);
    }

    return await response.json();
  }

  async listSites(): Promise<any[]> {
    const response = await fetch(`${this.netlifyApiUrl}/sites`, {
      headers: {
        'Authorization': `Bearer ${this.netlifyApiToken}`
      }
    });

    if (!response.ok) {
      throw new Error(`Failed to list sites: ${response.status}`);
    }

    const sites: any = await response.json();
    return sites.map((site: any) => ({
      id: site.id,
      name: site.name,
      url: site.ssl_url || site.url,
      customDomain: site.custom_domain,
      state: site.state,
      createdAt: site.created_at,
      updatedAt: site.updated_at
    }));
  }
}

export const netlifyDeploymentService = new NetlifyDeploymentService();