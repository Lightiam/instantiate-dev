import { ClientSecretCredential } from '@azure/identity';
import { ResourceManagementClient } from '@azure/arm-resources';
import { ContainerInstanceManagementClient } from '@azure/arm-containerinstance';

export class AzureDeploymentTest {
  private resourceClient: ResourceManagementClient;
  private containerClient: ContainerInstanceManagementClient;
  private subscriptionId: string;
  private credential: ClientSecretCredential;

  constructor() {
    this.subscriptionId = process.env.AZURE_SUBSCRIPTION_ID!;
    
    // Create fresh credential instance with current environment variables
    this.credential = new ClientSecretCredential(
      process.env.AZURE_TENANT_ID!,
      process.env.AZURE_CLIENT_ID!,
      process.env.AZURE_CLIENT_SECRET!
    );

    this.resourceClient = new ResourceManagementClient(this.credential, this.subscriptionId);
    this.containerClient = new ContainerInstanceManagementClient(this.credential, this.subscriptionId);
  }

  async testFullDeployment() {
    const resourceGroupName = `instanti8-test-${Date.now()}`;
    const containerName = 'nginx-test-app';
    const location = 'eastus';

    try {
      console.log('Starting Azure deployment test...');

      // Step 1: Create Resource Group
      console.log('Creating resource group:', resourceGroupName);
      await this.resourceClient.resourceGroups.createOrUpdate(resourceGroupName, {
        location: location,
        tags: {
          'created-by': 'instanti8-platform',
          'purpose': 'deployment-test',
          'timestamp': new Date().toISOString()
        }
      });
      console.log('Resource group created');

      // Step 2: Deploy Container Instance with updated API version
      console.log('Deploying container instance:', containerName);
      const containerGroup = await this.containerClient.containerGroups.beginCreateOrUpdateAndWait(
        resourceGroupName,
        containerName,
        {
          location: location,
          containers: [
            {
              name: containerName,
              image: 'nginx:latest',
              resources: {
                requests: {
                  cpu: 1,
                  memoryInGb: 1.5
                }
              },
              ports: [{ port: 80 }],
              environmentVariables: [
                { name: 'DEPLOYED_BY', value: 'Instanti8-Platform' },
                { name: 'DEPLOYMENT_TIME', value: new Date().toISOString() }
              ]
            }
          ],
          osType: 'Linux',
          ipAddress: {
            type: 'Public',
            ports: [{ protocol: 'TCP', port: 80 }]
          },
          tags: {
            'created-by': 'instanti8-platform',
            'deployment-test': 'true',
            'container-type': 'nginx-web-server'
          }
        }
      );

      console.log('Container deployed successfully');
      
      const result = {
        success: true,
        resourceGroup: resourceGroupName,
        containerName: containerName,
        publicIp: containerGroup.ipAddress?.ip,
        fqdn: containerGroup.ipAddress?.fqdn,
        status: containerGroup.provisioningState,
        location: location,
        deploymentTime: new Date().toISOString()
      };

      // Schedule cleanup after 5 minutes
      setTimeout(async () => {
        try {
          await this.cleanupResourceGroup(resourceGroupName);
          console.log(`Cleanup completed for ${resourceGroupName}`);
        } catch (error) {
          console.error(`Cleanup failed for ${resourceGroupName}:`, error);
        }
      }, 300000); // 5 minutes

      return result;

    } catch (error: any) {
      console.error('Deployment failed:', error.message);
      return {
        success: false,
        error: error.message,
        details: error.stack,
        resourceGroup: resourceGroupName
      };
    }
  }

  async cleanupResourceGroup(resourceGroupName: string) {
    try {
      await this.resourceClient.resourceGroups.beginDeleteAndWait(resourceGroupName);
      return { success: true, message: `Resource group ${resourceGroupName} deleted` };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async cleanupTestResources() {
    const resourceGroupName = 'instanti8-test-rg';
    
    try {
      console.log('Cleaning up test resources...');
      await this.resourceClient.resourceGroups.beginDeleteAndWait(resourceGroupName);
      console.log('✅ Test resources cleaned up');
      return { success: true };
    } catch (error: any) {
      console.error('❌ Cleanup failed:', error.message);
      return { success: false, error: error.message };
    }
  }

  async listResourceGroups() {
    try {
      const resourceGroups = [];
      for await (const rg of this.resourceClient.resourceGroups.list()) {
        resourceGroups.push({
          name: rg.name,
          location: rg.location,
          provisioningState: rg.provisioningState
        });
      }
      return { success: true, resourceGroups };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export const azureDeploymentTest = new AzureDeploymentTest();