import { URLSearchParams } from 'url';
import fetch from 'node-fetch';

interface SimpleAzureDeployment {
  name: string;
  code: string;
  codeType: 'javascript' | 'python' | 'html';
  resourceGroup: string;
  location: string;
}

export class AzureSimpleDeployment {
  private credentials = {
    clientId: "abb8ccdc-a48e-4b14-979e-161f4f3072f0",
    clientSecret: "Yam8Q~0ZhFR7r3ALz2DBOFr2qMkHePj4HzwJ1crn",
    tenantId: "4d2858d9-441d-46f0-b085-60e4ca7a5e75",
    subscriptionId: "3e513234-2b8a-4b15-8632-203397fae29f"
  };

  private async getAccessToken(): Promise<string> {
    const tokenUrl = `https://login.microsoftonline.com/${this.credentials.tenantId}/oauth2/v2.0/token`;
    
    const params = new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: this.credentials.clientId,
      client_secret: this.credentials.clientSecret,
      scope: 'https://management.azure.com/.default'
    });

    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });

    const data: any = await response.json();
    if (!response.ok) {
      throw new Error(`Azure authentication failed: ${JSON.stringify(data)}`);
    }

    return data.access_token;
  }

  async deployToAzure(spec: SimpleAzureDeployment): Promise<any> {
    // Create resource group with metadata to store deployment information
    const token = await this.getAccessToken();
    const resourceGroupPath = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups/${spec.resourceGroup}`;
    
    const body = {
      location: spec.location,
      tags: {
        'created-by': 'instanti8-platform',
        'deployment-type': 'code-storage',
        'code-type': spec.codeType,
        'app-name': spec.name,
        'deployed-at': new Date().toISOString(),
        'user-code': Buffer.from(spec.code.substring(0, 500)).toString('base64')
      }
    };

    const response = await fetch(`https://management.azure.com${resourceGroupPath}?api-version=2021-04-01`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Azure deployment failed: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    
    return {
      deploymentId: `azure-simple-${Date.now()}`,
      status: 'Deployed',
      url: `https://portal.azure.com/#@${this.credentials.tenantId}/resource${resourceGroupPath}`,
      provider: 'azure-simple',
      resourceGroup: spec.resourceGroup,
      location: spec.location,
      codeStored: true,
      metadata: {
        name: spec.name,
        codeType: spec.codeType,
        deployedAt: new Date().toISOString()
      }
    };
  }

  async listDeployments(): Promise<any[]> {
    const token = await this.getAccessToken();
    const path = `/subscriptions/${this.credentials.subscriptionId}/resourceGroups`;
    
    const response = await fetch(`https://management.azure.com${path}?api-version=2021-04-01&$filter=tagName eq 'created-by' and tagValue eq 'instanti8-platform'`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      return [];
    }

    const result: any = await response.json();
    return (result.value || []).map((rg: any) => ({
      name: rg.tags?.['app-name'] || rg.name,
      resourceGroup: rg.name,
      location: rg.location,
      deployedAt: rg.tags?.['deployed-at'],
      codeType: rg.tags?.['code-type'],
      url: `https://portal.azure.com/#@${this.credentials.tenantId}/resource${rg.id}`
    }));
  }
}

export const azureSimpleDeployment = new AzureSimpleDeployment();